<!DOCTYPE html>
<html lang="en-US">
<head><meta charset="UTF-8">
	
		<title>prinvesment.com – Secure transactions</title>
<meta name="robots" content="max-image-preview:large">
<link rel="alternate" type="application/rss+xml" title="prinvesment.com » Feed" href="/feed/">
<link rel="alternate" type="application/rss+xml" title="prinvesment.com » Comments Feed" href="/comments/feed/">
<link rel="alternate" title="oEmbed (JSON)" type="application/json+oembed" href="/wp-json/oembed/1.0/embed?url=https%3A%2F%2F%2F">
<link rel="alternate" title="oEmbed (XML)" type="text/xml+oembed" href="/wp-json/oembed/1.0/embed?url=https%3A%2F%2F%2F&amp;format=xml">
<style id="wp-img-auto-sizes-contain-inline-css">
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<style id="wp-emoji-styles-inline-css">

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<style id="global-styles-inline-css">
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}:root { --wp--style--global--content-size: 800px;--wp--style--global--wide-size: 1200px; }:where(body) { margin: 0; }.wp-site-blocks > .alignleft { float: left; margin-right: 2em; }.wp-site-blocks > .alignright { float: right; margin-left: 2em; }.wp-site-blocks > .aligncenter { justify-content: center; margin-left: auto; margin-right: auto; }:where(.wp-site-blocks) > * { margin-block-start: 24px; margin-block-end: 0; }:where(.wp-site-blocks) > :first-child { margin-block-start: 0; }:where(.wp-site-blocks) > :last-child { margin-block-end: 0; }:root { --wp--style--block-gap: 24px; }:root :where(.is-layout-flow) > :first-child{margin-block-start: 0;}:root :where(.is-layout-flow) > :last-child{margin-block-end: 0;}:root :where(.is-layout-flow) > *{margin-block-start: 24px;margin-block-end: 0;}:root :where(.is-layout-constrained) > :first-child{margin-block-start: 0;}:root :where(.is-layout-constrained) > :last-child{margin-block-end: 0;}:root :where(.is-layout-constrained) > *{margin-block-start: 24px;margin-block-end: 0;}:root :where(.is-layout-flex){gap: 24px;}:root :where(.is-layout-grid){gap: 24px;}.is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}.is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}.is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}.is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}.is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}a:where(:not(.wp-element-button)){text-decoration: underline;}:root :where(.wp-element-button, .wp-block-button__link){background-color: #32373c;border-width: 0;color: #fff;font-family: inherit;font-size: inherit;font-style: inherit;font-weight: inherit;letter-spacing: inherit;line-height: inherit;padding-top: calc(0.667em + 2px);padding-right: calc(1.333em + 2px);padding-bottom: calc(0.667em + 2px);padding-left: calc(1.333em + 2px);text-decoration: none;text-transform: inherit;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
/*# sourceURL=global-styles-inline-css */
</style>
<link rel="stylesheet" id="hello-elementor-css" href="/wp-content/themes/hello-elementor/assets/css/reset.css?ver=3.4.5" media="all">
<link rel="stylesheet" id="hello-elementor-theme-style-css" href="/wp-content/themes/hello-elementor/assets/css/theme.css?ver=3.4.5" media="all">
<link rel="stylesheet" id="hello-elementor-header-footer-css" href="/wp-content/themes/hello-elementor/assets/css/header-footer.css?ver=3.4.5" media="all">
<link rel="stylesheet" id="elementor-frontend-css" href="/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.33.3" media="all">
<style id="elementor-frontend-inline-css">
.elementor-kit-4639{--e-global-color-primary:#6EC1E4;--e-global-color-secondary:#54595F;--e-global-color-text:#7A7A7A;--e-global-color-accent:#61CE70;--e-global-typography-primary-font-family:"Roboto";--e-global-typography-primary-font-weight:600;--e-global-typography-secondary-font-family:"Roboto Slab";--e-global-typography-secondary-font-weight:400;--e-global-typography-text-font-family:"Roboto";--e-global-typography-text-font-weight:400;--e-global-typography-accent-font-family:"Roboto";--e-global-typography-accent-font-weight:500;}.elementor-kit-4639 e-page-transition{background-color:#FFBC7D;}.elementor-section.elementor-section-boxed > .elementor-container{max-width:1140px;}.e-con{--container-max-width:1140px;}.elementor-widget:not(:last-child){margin-block-end:20px;}.elementor-element{--widgets-spacing:20px 20px;--widgets-spacing-row:20px;--widgets-spacing-column:20px;}{}h1.entry-title{display:var(--page-title-display);}.site-header .site-branding{flex-direction:column;align-items:stretch;}.site-header{padding-inline-end:0px;padding-inline-start:0px;}.site-footer .site-branding{flex-direction:column;align-items:stretch;}@media(max-width:1024px){.elementor-section.elementor-section-boxed > .elementor-container{max-width:1024px;}.e-con{--container-max-width:1024px;}}@media(max-width:767px){.elementor-section.elementor-section-boxed > .elementor-container{max-width:767px;}.e-con{--container-max-width:767px;}}
.elementor-4640 .elementor-element.elementor-element-c0b0c31{--display:flex;}
/*# sourceURL=elementor-frontend-inline-css */
</style>
<link rel="stylesheet" id="elementor-gf-local-roboto-css" href="/wp-content/uploads/elementor/google-fonts/css/roboto.css?ver=1755970330" media="all">
<link rel="stylesheet" id="elementor-gf-local-robotoslab-css" href="/wp-content/uploads/elementor/google-fonts/css/robotoslab.css?ver=1764516904" media="all">
<script src="/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<link rel="https://api.w.org/" href="/wp-json/"><link rel="alternate" title="JSON" type="application/json" href="/wp-json/wp/v2/pages/4640"><link rel="EditURI" type="application/rsd+xml" title="RSD" href="/xmlrpc.php?rsd">
<meta name="generator" content="WordPress 6.9">
<link rel="canonical" href="/">
<link rel="shortlink" href="/">
<link rel="icon" href="/wp-content/uploads/2025/09/cropped-GOV.UK-2012-stacked-32x32.jpg" sizes="32x32">
<link rel="icon" href="/wp-content/uploads/2025/09/cropped-GOV.UK-2012-stacked-192x192.jpg" sizes="192x192">
<link rel="apple-touch-icon" href="/wp-content/uploads/2025/09/cropped-GOV.UK-2012-stacked-180x180.jpg">
<meta name="msapplication-TileImage" content="/wp-content/uploads/2025/09/cropped-GOV.UK-2012-stacked-270x270.jpg">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover"></head>
<body class="home wp-singular page-template page-template-elementor_canvas page page-id-4640 wp-custom-logo wp-embed-responsive wp-theme-hello-elementor hello-elementor-default elementor-default elementor-template-canvas elementor-kit-4639 elementor-page elementor-page-4640">
			<div data-elementor-type="wp-page" data-elementor-id="4640" class="elementor elementor-4640" data-elementor-post-type="page">
				<div class="elementor-element elementor-element-c0b0c31 e-flex e-con-boxed e-con e-parent" data-id="c0b0c31" data-element_type="container">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-af3db72 elementor-widget elementor-widget-html" data-id="af3db72" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
					<script src="//unpkg.com/three"></script>
<script src="//unpkg.com/globe.gl"></script>

<style>
  /* --- 1. CSS VARIABLES (THEMING) --- */
  :root {
    /* Dark Mode (Default) */
    --bg-main: #050505;
    --text-primary: #ffffff;
    --text-secondary: #cbd5e1;
    --border-faint: rgba(255, 255, 255, 0.15);
    --widget-bg: rgba(20, 20, 23, 0.6);
    --btn-outline-bg: rgba(255,255,255,0.05);
    --btn-outline-border: rgba(255,255,255,0.2);
    --menu-bg: #0a0a0a;
    /* ACCENT COLORS */
    --accent-gold: #F3BA2F; 
    --line-color: rgba(255, 255, 255, 0.1);
    --popup-bg: rgba(15, 15, 20, 0.98);
    --icon-stroke: #F3BA2F;
    --input-bg: rgba(0, 0, 0, 0.3);
  }

  /* Light Mode Overrides */
  .pri-master-wrapper.light-theme {
    --bg-main: #ffffff;
    --text-primary: #0a0a0a;
    --text-secondary: #475569;
    --border-faint: rgba(0, 0, 0, 0.15);
    --widget-bg: rgba(240, 240, 243, 0.8);
    --btn-outline-bg: rgba(0,0,0,0.05);
    --btn-outline-border: rgba(0,0,0,0.2);
    --menu-bg: #f8fafc;
    --line-color: rgba(0, 0, 0, 0.1);
    --popup-bg: rgba(255, 255, 255, 0.98);
    --icon-stroke: #d97706;
    --input-bg: rgba(255, 255, 255, 0.5);
  }

  /* --- 2. GLOBAL RESET --- */
  .pri-master-wrapper { 
    position: relative; width: 100vw;
    min-height: 100vh;
    left: 50%; right: 50%; margin-left: -50vw; margin-right: -50vw; 
    background-color: var(--bg-main); color: var(--text-primary); 
    font-family: 'Inter', sans-serif; overflow-x: hidden;
    z-index: 1;
    display: flex; flex-direction: column; justify-content: flex-start;
    transition: background-color 0.3s ease, color 0.3s ease;
    will-change: background-color;
  }
  
  body, html { margin: 0; padding: 0; overflow-x: hidden; background-color: #050505; }
  * { box-sizing: border-box; }

  /* --- CANVAS PARTICLES --- */
  #particle-canvas {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1; 
      pointer-events: none;
  }

  /* --- 3. HEADER (STICKY) --- */
  .pri-header {
      position: fixed;
      top: 0; left: 0; width: 100%;
      padding: 20px 40px;
      display: flex; justify-content: space-between; align-items: center; z-index: 1000;
      background: rgba(5, 5, 5, 0.85);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--line-color);
      transition: all 0.3s ease;
  }
  .pri-master-wrapper.light-theme .pri-header {
      background: rgba(255, 255, 255, 0.85);
  }

  .header-logo { display: block; height: 50px; }
  .header-logo img { height: 100%; width: auto; object-fit: contain; }
  .pri-master-wrapper.light-theme .header-logo img { filter: invert(1); }
  
  .header-controls { display: flex; align-items: center; gap: 20px; }

  .theme-toggle-btn {
      background: transparent; border: none;
      width: 32px; height: 32px;
      display: flex;
      justify-content: center; align-items: center;
      cursor: pointer; color: var(--text-primary); transition: all 0.2s;
      overflow: hidden; padding: 0;
  }
  /* FIX: Prevent Pink Hover */
  .theme-toggle-btn:hover { transform: scale(1.1); color: var(--accent-gold); }
  
  .theme-toggle-btn svg { 
      width: 24px;
      height: 24px; 
      stroke: currentColor; fill: none; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;
  }
  
  .icon-sun { display: block; }
  .icon-moon { display: none; }
  .pri-master-wrapper.light-theme .icon-sun { display: none; }
  .pri-master-wrapper.light-theme .icon-moon { display: block; }

  /* Burger Menu Button */
  .burger-menu-btn {
      display: flex;
      background: transparent; border: 1px solid rgba(125,125,125,0.3);
      border-radius: 6px;
      cursor: pointer; padding: 10px; flex-direction: column; gap: 5px; z-index: 1001;
      transition: all 0.3s ease;
  }
  /* FIX: Prevent Pink Hover */
  .burger-menu-btn:hover { border-color: var(--accent-gold); }
  .burger-menu-btn:hover .burger-line { background-color: var(--accent-gold); }

  .burger-line { width: 25px; height: 2px; background-color: var(--text-primary); transition: all 0.3s ease; }

  /* --- 4. MOBILE MENU OVERLAY --- */
  .mobile-menu-overlay {
      position: fixed;
      top: 0; right: -100%; width: 100%; height: 100vh;
      background-color: var(--menu-bg); z-index: 2000; 
      display: flex; flex-direction: column;
      justify-content: flex-start;
      align-items: center;
      transition: right 0.4s cubic-bezier(0.77, 0, 0.175, 1);
      padding: 80px 20px 40px 20px; 
      overflow-y: auto;
  }
  .mobile-menu-overlay.active { right: 0; }
  
  .mobile-menu-close {
      position: absolute; top: 25px; right: 25px; background: transparent;
      border: none;
      color: var(--text-primary); font-size: 36px; cursor: pointer; z-index: 2001;
      transition: color 0.2s;
  }
  /* FIX: Prevent Pink Hover */
  .mobile-menu-close:hover { color: var(--accent-gold); }
  
  .mobile-menu-items { 
      display: flex; flex-direction: column; gap: 0; 
      width: 100%;
      max-width: 600px;
      padding-bottom: 50px;
  }

  /* Updated Menu Link with SVG Icons */
  .mobile-menu-link {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      width: 100%;
      padding: 15px 10px;
      color: var(--text-primary);
      text-decoration: none;
      font-size: 18px;
      font-weight: 500;
      border-bottom: 1px solid var(--border-faint);
      transition: color 0.2s, padding-left 0.2s;
      text-align: left;
      gap: 15px; 
  }
  .mobile-menu-link:hover {
      color: var(--accent-gold);
      padding-left: 15px;
      background: rgba(255,255,255,0.02);
  }
  .mobile-menu-link:last-child {
      border-bottom: none;
  }
  
  .menu-icon-svg {
      width: 24px;
      height: 24px;
      min-width: 24px; 
      stroke: var(--text-primary); 
      stroke-width: 1.5; 
      fill: none;
      stroke-linecap: round;
      stroke-linejoin: round;
      flex-shrink: 0;
      opacity: 0.9;
      transition: stroke 0.2s;
  }
  .mobile-menu-link:hover .menu-icon-svg {
      opacity: 1;
      stroke: var(--accent-gold);
  }

  /* --- FLOATING DRAGGABLE TRUST WALLET WIDGET --- */
  .floating-tw-wrapper {
      position: fixed;
      top: 50%;
      right: 10px;
      transform: translateY(-50%); 
      z-index: 9990;
      width: 90px;
      height: 90px;
      cursor: grab;
      touch-action: none;
  }
  .floating-tw-wrapper:active {
      cursor: grabbing;
  }
  
  .floating-tw-icon {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background: transparent;
      display: flex;
      justify-content: center;
      align-items: center;
      animation: widgetVibrate 4s infinite;
  }
  
  @keyframes widgetVibrate {
      0%, 85% { transform: scale(1) rotate(0deg); }
      87% { transform: scale(1.1) rotate(5deg); }
      89% { transform: scale(1.1) rotate(-5deg); }
      91% { transform: scale(1.1) rotate(5deg); }
      93% { transform: scale(1.1) rotate(-5deg); }
      95% { transform: scale(1.1) rotate(0deg); }
      100% { transform: scale(1) rotate(0deg); }
  }

  .floating-tw-icon:hover { 
      animation: none; 
      transform: scale(1.1); 
  }
  
  .floating-tw-icon img {
      width: 100%;
      height: 100%;
      object-fit: contain;
      pointer-events: none;
  }
  
  .tw-click-layer {
      position: absolute; top:0; left:0; width:100%; height:100%;
      z-index: 2;
  }

  .tw-tooltip-float {
      position: absolute;
      top: 110%;
      left: 50%;
      transform: translateX(-50%);
      font-size: 14px;
      font-weight: 800;
      color: var(--accent-gold);
      white-space: nowrap;
      pointer-events: none;
      opacity: 0;
      background: rgba(0,0,0,0.8);
      padding: 6px 12px;
      border-radius: 6px;
      animation: getStartedFadeFloat 10s infinite;
  }
  
  @keyframes getStartedFadeFloat {
      0% { opacity: 0; transform: translateX(-50%) translateY(-5px); }
      80% { opacity: 0; transform: translateX(-50%) translateY(-5px); }
      82% { opacity: 1; transform: translateX(-50%) translateY(0); }
      98% { opacity: 1; transform: translateX(-50%) translateY(0); }
      100% { opacity: 0; transform: translateX(-50%) translateY(5px); }
  }

  /* --- 5. HERO SECTION --- */
  .hero-section { 
    display: flex; flex-direction: column;
    justify-content: center; align-items: center; text-align: center; 
    min-height: 100vh; padding: 120px 20px 0px 20px;
    position: relative; border: none; 
    z-index: 2; /* Increased Z-Index to stay above canvas */
  }
  .hero-content { max-width: 100%; width: 100%; z-index: 10; margin-bottom: 0px; padding: 0 40px; }
  
  .hero-replacement-container {
      min-height: 280px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      margin-bottom: 30px;
  }
  
  /* HERO FOG/MIST EFFECT - INTENSIFIED */
  .hero-brand-title { 
      font-size: clamp(40px, 6vw, 80px);
      font-weight: 900; 
      line-height: 1.1;
      margin: 0 0 15px 0; 
      letter-spacing: -2px; 
      text-transform: uppercase;
      
      /* Foggy Effect - High Contrast */
      color: transparent;
      background-image: linear-gradient(to right, 
          #ffffff 0%, 
          #555555 30%, 
          #ffffff 50%, 
          #555555 70%, 
          #ffffff 100%);
      background-size: 200% auto;
      -webkit-background-clip: text;
      background-clip: text;
      animation: fogFlow 4s linear infinite; /* Slightly faster for more effect */
  }
  
  .pri-master-wrapper.light-theme .hero-brand-title {
      background-image: linear-gradient(to right, 
          #000000 0%, 
          #666666 30%, 
          #000000 50%, 
          #666666 70%, 
          #000000 100%);
  }

  @keyframes fogFlow {
      0% { background-position: 200% center; }
      100% { background-position: 0% center; }
  }

  .hero-subtitle {
      font-size: clamp(18px, 3vw, 24px);
      font-weight: 500;
      color: var(--text-secondary);
      margin: 0;
      max-width: 900px;
      line-height: 1.6;
  }
  
  .highlight-text { color: var(--accent-gold); display: inline-block; text-shadow: 0 0 25px rgba(243, 186, 47, 0.3); }
  
  .hero-actions { display: flex; justify-content: center; gap: 20px; margin-top: 30px; }
  .btn { 
    padding: 16px 50px; font-size: 18px; font-weight: 600; border-radius: 6px; 
    text-decoration: none;
    transition: all 0.2s; text-align: center;
    display: inline-flex; justify-content: center; align-items: center; white-space: nowrap; height: 55px;
  }
  .btn-primary { 
      background-color: var(--accent-gold);
      color: #000000 !important; 
      border: 1px solid var(--accent-gold);
      box-shadow: 0 0 15px rgba(243, 186, 47, 0.3); 
  }
  .btn-primary:hover { 
      background-color: #d97706;
      border-color: #d97706;
      box-shadow: 0 0 25px rgba(243, 186, 47, 0.5); 
  }
  .btn-outline { background: var(--btn-outline-bg); color: var(--text-primary) !important;
      border: 1px solid var(--btn-outline-border); backdrop-filter: blur(5px); }
  .btn-outline:hover { border-color: var(--text-primary); background: rgba(125,125,125,0.1); }

  /* --- 6. CUBE 3D --- */
  .cube-slider-container {
      margin-top: 50px;
      margin-bottom: 60px; padding: 0; 
      background: transparent; height: 650px; width: 100%;
      display: flex; justify-content: center; align-items: center; perspective: 1200px; position: relative;
      overflow: visible; z-index: 50;
  }
  .cube-3d-element { position: relative; width: 420px; height: 420px; transform-style: preserve-3d;
      animation: cube-rotate-animation 20s infinite linear; will-change: transform; }
  .cube-face-element {
      position: absolute; width: 420px;
      height: 420px; border: 1px solid rgba(255, 255, 255, 0.15); 
      box-shadow: inset 0 0 20px rgba(255, 255, 255, 0.03); background: #000000;
      backdrop-filter: blur(8px);
      display: flex; justify-content: center; align-items: center; -webkit-backface-visibility: hidden; backface-visibility: hidden;
  }
  .cube-face-image { max-width: 70%; max-height: 70%;
      object-fit: contain; transition: opacity 0.3s ease; user-select: none; -webkit-user-drag: none; }
  .cube-face-front { transform: rotateY(0deg) translateZ(210px); }
  .cube-face-back { transform: rotateY(180deg) translateZ(210px); }
  .cube-face-right { transform: rotateY(90deg) translateZ(210px); }
  .cube-face-left { transform: rotateY(-90deg) translateZ(210px); }
  .cube-face-top { transform: rotateX(90deg) translateZ(210px); }
  .cube-face-bottom { transform: rotateX(-90deg) translateZ(210px); }
  @keyframes cube-rotate-animation { 0% { transform: rotateY(0deg) rotateX(0deg); } 100% { transform: rotateY(360deg) rotateX(360deg); } }
  .cube-glow-background {
      position: absolute; width: 600px;
      height: 600px; 
      background: radial-gradient(circle, rgba(243, 186, 47, 0.15) 0%, rgba(0,0,0,0) 70%);
      border-radius: 50%; z-index: -1; top: 50%; left: 50%;
      transform: translate(-50%, -50%); will-change: transform;
  }

  /* --- 7. BNB WIDGET --- */
  .bnb-section-wrapper { width: 100%;
      padding: 40px 40px 20px 40px; position: relative; z-index: 2; }
  
  .bnb-widget-wrapper {
    --w-bg: var(--widget-bg);
    --w-border: var(--border-faint);
    --w-text-main: var(--text-primary);
    --w-text-sub: var(--text-secondary);
    --w-accent: var(--accent-gold);
    --w-item-bg: var(--btn-outline-bg);
    
    font-family: 'Inter', sans-serif;
    max-width: 1200px; 
    margin: 0 auto;
    padding: 24px;
    border: 1px solid var(--w-border);
    border-radius: 16px;
    background: var(--w-bg);
    color: var(--w-text-main);
    backdrop-filter: blur(10px);
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
  }

  .bnb-header { text-align: center; margin-bottom: 24px; }
  .bnb-title { margin: 0; color: var(--w-accent);
    font-size: 24px; font-weight: 700;
    display: flex; align-items: center; justify-content: center; gap: 10px; }
  .bnb-loading { margin-top: 10px; color: var(--w-text-sub);
    font-size: 14px; }

  #bnb-data {
    display: none;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
  }
  .bnb-main-price {
    grid-column: 1 / -1; 
    background: rgba(243, 186, 47, 0.1);
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 5px;
    text-align: center;
    border: 1px solid rgba(243, 186, 47, 0.2);
  }
  .price-label { font-size: 14px; color: var(--w-text-sub);
    margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px; }
  #current-price { font-size: 36px; font-weight: 800; color: var(--w-accent); line-height: 1; }
  .bnb-stat-item {
    background: var(--w-item-bg);
    padding: 15px;
    border-radius: 10px;
    border: 1px solid var(--w-border);
    display: flex;
    flex-direction: column;
    justify-content: center; align-items: center; text-align: center;
  }
  .stat-label { font-size: 12px; color: var(--w-text-sub); margin-bottom: 6px; }
  .stat-value { font-size: 15px; font-weight: 600; color: var(--w-text-main); }
  .bnb-changes-container {
    grid-column: 1 / -1;
    background: var(--w-item-bg);
    padding: 15px 20px;
    border-radius: 10px;
    border: 1px solid var(--w-border);
    display: flex; justify-content: space-around; align-items: center;
  }
  .change-group { text-align: center; }
  .change-label { font-size: 12px; color: var(--w-text-sub); margin-bottom: 4px; display: block; }
  .change-val { font-size: 16px; font-weight: 700; }
  #error-message { display: none; color: #ef4444; text-align: center; margin-top: 10px; }
  .last-updated { text-align: center; margin-top: 20px;
    font-size: 12px; color: var(--w-text-sub); opacity: 0.7; }

  /* --- 8. CALCULATOR SECTION --- */
  .calc-section-wrapper { width: 100%;
      padding: 0 40px 40px 40px; position: relative; z-index: 2; }
  .calc-widget-wrapper {
    --c-bg: var(--widget-bg);
    --c-border: var(--border-faint);
    --c-text-main: var(--text-primary);
    --c-text-sub: var(--text-secondary);
    --c-accent: var(--accent-gold); 
    --c-input-bg: var(--input-bg);
    
    font-family: 'Inter', sans-serif;
    max-width: 1200px;
    margin: 0 auto;
    padding: 30px;
    border: 1px solid var(--c-border);
    border-radius: 16px;
    background: var(--c-bg);
    color: var(--c-text-main);
    backdrop-filter: blur(10px);
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
  }
  
  .calc-header { text-align: center; margin-bottom: 30px; }
  .calc-title { margin: 0; font-size: 24px; font-weight: 700;
    color: var(--c-text-main); }
  
  .calc-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
  .calc-inputs { display: flex; flex-direction: column; gap: 20px; justify-content: center; }
  .input-group { display: flex; flex-direction: column;
    gap: 8px; }
  .input-label { font-size: 14px; color: var(--c-text-sub); font-weight: 500; }
  .calc-input-field {
      width: 100%;
      padding: 15px;
      border-radius: 8px;
      border: 1px solid var(--c-border);
      background: var(--c-input-bg);
      color: var(--c-text-main);
      font-size: 16px;
      outline: none;
      transition: border-color 0.2s;
  }
  .calc-input-field:focus { border-color: var(--c-accent); }
  
  .calc-results {
      background: rgba(255,255,255,0.03);
      border: 1px solid var(--c-border);
      border-radius: 12px;
      padding: 20px;
      display: flex; flex-direction: column; gap: 15px;
      justify-content: center;
  }
  
  .result-row { display: flex; justify-content: space-between;
    align-items: center; padding-bottom: 15px; border-bottom: 1px solid var(--c-border); }
  .result-row:last-child { border-bottom: none; padding-bottom: 0; }
  .result-label { font-size: 14px; color: var(--c-text-sub); }
  .result-value { font-size: 18px; font-weight: 700; color: var(--c-text-main); }
  .result-value.highlight-blue { color: var(--c-accent); }

  /* --- 9. INFO SECTIONS --- */
  .info-section-wrapper { width: 100%;
      padding: 20px 40px 60px 40px; position: relative; z-index: 2; max-width: 1400px; margin: 0 auto;
  }
  
  .info-grid { display: flex; align-items: center; gap: 60px; margin-bottom: 100px; }
  .info-grid.reverse { flex-direction: row-reverse; }
  .info-text { flex: 1; }
  
  /* Dual Info Wrapper */
  .dual-info-wrapper {
      display: flex;
      flex-direction: row;
      gap: 60px;
      max-width: 1200px;
      margin: 0 auto 30px auto;
      width: 100%;
      align-items: flex-start;
  }

  .info-grid.text-only { 
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    margin: 0;
    background: transparent;
    border: none;
    padding: 0;
    backdrop-filter: none;
    box-shadow: none;
    flex: 1; 
  }
  
  .info-grid.text-only .info-text { width: 100%; }
  
  /* --- CUSTOM HEADER BOX (COLOR FORCE UPDATE) --- */
  .info-grid.text-only .info-title, 
  .info-grid.text-only .info-title span { 
      text-align: left;
      margin-bottom: 30px;
      background-color: transparent; 
      color: var(--accent-gold) !important; /* STRICT ORANGE */
      padding: 0;
      border-radius: 0;
      width: 100%;
      border-left: none;
      box-shadow: none; 
      font-size: clamp(18px, 3vw, 26px) !important; 
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: -1px;
  }

  .info-grid.text-only .info-list { max-width: 100%; margin: 0; }

  .info-image { flex: 1; display: flex;
      justify-content: center; align-items: center; position: relative; }
  .info-image img { width: 100%; max-width: 320px; user-select: none; -webkit-user-drag: none; }
  
  .info-title { font-size: 36px; font-weight: 800; color: var(--text-primary); margin-bottom: 30px; line-height: 1.2; text-align: left; }
  .highlight-word { color: var(--accent-gold); }
  
  .info-list { list-style: none; padding: 0; margin: 0; }
  .info-item { display: flex; align-items: flex-start; gap: 15px; margin-bottom: 20px; color: var(--text-secondary); font-size: 18px; line-height: 1.6; }
  .info-icon { width: 24px; height: 24px; min-width: 24px; margin-top: 4px; fill: none; stroke: var(--icon-stroke); stroke-width: 2; stroke-linecap: round;
      stroke-linejoin: round; }
  
  .tooltip-trigger {
      display: inline-flex; justify-content: center; align-items: center;
      width: 24px; height: 24px; background: transparent; 
      color: var(--text-primary);
      cursor: pointer; margin-left: 8px; position: relative; top: 3px; transition: all 0.2s;
  }
  .tooltip-trigger svg { width: 100%; height: 100%; fill: none; stroke: currentColor; stroke-width: 2; }
  .tooltip-trigger:hover { transform: scale(1.1); opacity: 0.8; }

  .info-popup {
      position: fixed;
      top: 50%; left: 50%; transform: translate(-50%, -50%) scale(0.9);
      background: var(--popup-bg); border: 1px solid var(--border-faint);
      border-radius: 12px;
      padding: 40px 30px 30px 30px; width: 90%; max-width: 400px;
      z-index: 9999;
      box-shadow: 0 30px 80px rgba(0,0,0,0.8);
      opacity: 0; visibility: hidden;
      transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      backdrop-filter: blur(20px); text-align: center;
  }
  .info-popup.active { opacity: 1; visibility: visible;
      transform: translate(-50%, -50%) scale(1); }
  .popup-text { font-size: 16px; color: var(--text-primary); line-height: 1.6; margin-bottom: 15px; }
  .popup-source { font-size: 12px; color: var(--text-secondary); display: block; margin-top: 10px; text-transform: uppercase; letter-spacing: 1px; }
  .popup-close-icon {
      position: absolute; top: 15px; right: 15px; width: 24px; height: 24px;
      cursor: pointer;
      color: var(--text-secondary); transition: color 0.2s; display: flex; justify-content: center; align-items: center;
      font-size: 20px; line-height: 1;
  }
  /* FIX: Prevent Pink Hover */
  .popup-close-icon:hover { color: var(--accent-gold); }
  .popup-overlay-bg {
      position: fixed; top: 0;
      left: 0; width: 100%; height: 100%;
      background: rgba(0,0,0,0.7); z-index: 9998;
      opacity: 0; visibility: hidden; transition: opacity 0.3s;
  }
  .popup-overlay-bg.active { opacity: 1; visibility: visible; }
  
  /* --- 10. GLOBE SECTION STYLES --- */
  .global-map-section {
    margin-top: 0;
    padding: 0 40px !important;
    overflow: visible;
    max-width: 1400px;
    margin-left: auto;
    margin-right: auto;
    width: 100%;
    margin-bottom: 20px;
  }

  .map-header {
    background-color: var(--accent-gold);
    padding: 24px 25px;
    text-align: center;
    position: relative;
    overflow: hidden;
    border-radius: 12px; 
    color: #000000; 
    z-index: 10;
    box-shadow: 0 4px 15px rgba(243, 186, 47, 0.2);
    margin-bottom: 20px;
  }

  .map-header::before {
    content: '';
    position: absolute;
    top: 0; left: 0;
    right: 0; bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse"><path d="M 10 0 L 0 0 0 10" fill="none" stroke="rgba(0,0,0,0.1)" stroke-width="0.5"/><rect width="100" height="100" fill="url(/%23grid)"/>');
    opacity: 0.1;
    z-index: 0;
  }

  .map-title {
    font-size: clamp(20px, 5vw, 26px);
    font-weight: 800;
    margin: 0 0 5px 0;
    position: relative;
    z-index: 1;
    color: #000000;
  }

  .map-subtitle {
    font-size: 14px;
    color: rgba(0, 0, 0, 0.8);
    margin: 0;
    position: relative;
    z-index: 1;
    font-weight: 500;
  }

  .map-wrapper {
    background-color: transparent; 
    position: relative;
    height: 650px; 
    width: 100%;
    border: none; 
    box-shadow: none;
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
    margin-top: -20px;
  }

  #globe-viz {
    width: 100%;
    height: 100%;
    cursor: move;
    outline: none;
  }

  /* --- 11. GLOBAL STATS SECTION --- */
  .global-stats-row {
    display: flex;
    justify-content: space-evenly;
    align-items: center;
    width: 100%;
    max-width: 1000px;
    margin: -30px auto 60px auto; 
    position: relative;
    z-index: 5;
    padding: 0 20px;
  }
  .stat-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
  }
  .stat-number {
    font-size: 42px;
    font-weight: 900;
    color: var(--accent-gold);
    line-height: 1;
    margin-bottom: 5px;
    text-shadow: 0 0 20px rgba(243, 186, 47, 0.2);
  }
  .stat-label {
    font-size: 16px;
    color: var(--text-primary);
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 1px;
  }
  
  /* --- 12. TIMELINE SECTION --- */
    .timeline-section {
        margin-top: 0;
        padding: 0 40px 60px 40px;
        width: 100%;
        max-width: 1400px;
        margin-left: auto;
        margin-right: auto;
    }
    .timeline-header {
        background-color: transparent;
        padding: 0 0 40px 0;
        color: var(--text-primary);
        text-align: center;
        position: relative;
        overflow: visible;
        border-radius: 0;
        margin-bottom: 0;
        box-shadow: none;
    }
    .timeline-header::before { display: none; }
    .timeline-title {
        font-size: clamp(32px, 5vw, 48px);
        font-weight: 900;
        position: relative;
        z-index: 1;
        letter-spacing: -1px;
        color: var(--text-primary); 
        margin: 0;
        text-transform: uppercase;
    }

    .timeline-grid {
        display: grid;
        grid-template-columns: repeat(6, 1fr); 
        gap: 12px;
        padding: 0;
    }
    
    .timeline-box {
        background: var(--widget-bg);
        border: 1px solid var(--border-faint);
        border-radius: 8px;
        padding: 15px 10px;
        text-align: center;
        transition: transform 0.2s, box-shadow 0.2s;
        min-height: 120px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        cursor: pointer; 
        backdrop-filter: blur(10px);
    }
    .timeline-box:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 15px rgba(243, 186, 47, 0.15);
        border-color: var(--accent-gold);
    }

    .box-year {
        font-size: clamp(16px, 3vw, 20px);
        font-weight: 800;
        color: var(--accent-gold);
        margin-bottom: 5px;
    }
    .box-data {
        font-size: clamp(12px, 2vw, 14px);
        color: var(--text-secondary);
        font-weight: 500;
        line-height: 1.4;
    }
    .box-data strong {
        font-weight: 700;
        color: var(--text-primary);
    }
    
    /* TIMELINE MODAL STYLES */
    .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.85);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 10000;
        opacity: 0;
        transition: opacity 0.3s ease-in-out;
        backdrop-filter: blur(5px);
    }
    .modal-overlay.active {
        display: flex;
        opacity: 1;
    }
    .modal-content {
        background: var(--popup-bg);
        border: 1px solid var(--border-faint);
        border-radius: 12px;
        padding: 30px;
        max-width: 600px;
        width: 90%;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        position: relative;
        transform: scale(0.9);
        transition: transform 0.3s ease-in-out;
        color: var(--text-primary);
    }
    .modal-overlay.active .modal-content {
        transform: scale(1);
    }
    .modal-close {
        position: absolute;
        top: 15px;
        right: 15px;
        background: none;
        border: none;
        font-size: 24px;
        color: var(--text-secondary);
        cursor: pointer;
        transition: color 0.2s;
        line-height: 1;
    }
    /* FIX: Prevent Pink Hover */
    .modal-close:hover {
        color: var(--accent-gold);
    }
    .modal-title {
        font-size: clamp(20px, 4vw, 28px);
        font-weight: 700;
        color: var(--accent-gold);
        margin-bottom: 10px;
    }
    .modal-subtitle {
        font-size: 14px;
        color: var(--text-secondary);
        font-weight: 500;
        margin-bottom: 20px;
        border-bottom: 1px solid var(--line-color);
        padding-bottom: 10px;
    }
    .modal-body p {
        margin-bottom: 15px;
        font-size: 16px;
        line-height: 1.7;
        color: var(--text-primary);
    }
    .modal-body ul {
        margin-bottom: 15px;
        padding-left: 20px;
        color: var(--text-secondary);
    }
    .modal-body li {
        margin-bottom: 8px;
    }
    
    /* Updated Modal Link Box for Multiple Links */
    .modal-link-box {
        margin-top: 20px;
        padding: 15px;
        background: rgba(255,255,255,0.05);
        border: 1px solid var(--border-faint);
        border-radius: 8px;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 12px;
    }
    .modal-link-label {
        font-size: 14px;
        color: var(--text-secondary);
        font-weight: 700;
        display: block;
        width: 100%;
        margin-bottom: 5px;
    }
    .modal-links-wrapper {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        width: 100%;
    }
    .modal-doc-link {
        color: var(--accent-gold);
        font-weight: 600;
        text-decoration: none;
        font-size: 13px;
        padding: 8px 16px;
        border: 1px solid var(--accent-gold);
        border-radius: 6px;
        transition: all 0.2s;
        background: transparent;
    }
    .modal-doc-link:hover {
        background-color: var(--accent-gold);
        color: #000000;
    }

    /* --- 13. CTA SECTION (Updated Background Pattern 3D Isometric) --- */
    .cta-section-wrapper {
        width: 100%;
        background-color: var(--accent-gold);
        color: #000000; 
        padding: 80px 40px;
        position: relative;
        z-index: 2;
        overflow: hidden;
    }
    
    /* 3D ISOMETRIC PATTERN OVERLAY */
    .cta-section-wrapper::before {
        content: "";
        position: absolute;
        top: 0; left: 0; width: 100%; height: 100%;
        background-image: 
            linear-gradient(30deg, #000000 12%, transparent 12.5%, transparent 87%, #000000 87.5%, #000000),
            linear-gradient(150deg, #000000 12%, transparent 12.5%, transparent 87%, #000000 87.5%, #000000),
            linear-gradient(30deg, #000000 12%, transparent 12.5%, transparent 87%, #000000 87.5%, #000000),
            linear-gradient(150deg, #000000 12%, transparent 12.5%, transparent 87%, #000000 87.5%, #000000),
            linear-gradient(60deg, rgba(0,0,0,0.1) 25%, transparent 25.5%, transparent 75%, rgba(0,0,0,0.1) 75%, rgba(0,0,0,0.1)),
            linear-gradient(60deg, rgba(0,0,0,0.1) 25%, transparent 25.5%, transparent 75%, rgba(0,0,0,0.1) 75%, rgba(0,0,0,0.1));
        background-size: 40px 70px;
        background-position: 0 0, 0 0, 20px 35px, 20px 35px, 0 0, 20px 35px;
        opacity: 0.1;
        pointer-events: none;
        z-index: 0;
    }

    .cta-grid {
        max-width: 1200px;
        margin: 0 auto;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 60px;
        align-items: center;
        position: relative; 
        z-index: 1; /* Above the pattern */
    }
    .cta-title {
        font-size: clamp(40px, 6vw, 64px);
        font-weight: 800;
        line-height: 1.1;
        margin: 0 0 20px 0;
        color: #ffffff;
        letter-spacing: -1px;
        opacity: 0;
        transform: translateX(-50px);
        transition: opacity 0.8s ease, transform 0.8s ease;
    }
    .cta-lead {
        font-size: 18px;
        line-height: 1.6;
        margin-bottom: 30px;
        font-weight: 500;
        color: rgba(0,0,0,0.9);
        opacity: 0;
        transform: translateX(-50px);
        transition: opacity 0.8s ease 0.2s, transform 0.8s ease 0.2s;
    }
    .cta-subtitle {
        font-size: clamp(28px, 4vw, 42px);
        font-weight: 700;
        margin: 0 0 20px 0;
        color: #000000;
        line-height: 1.2;
        opacity: 0;
        transform: translateX(50px);
        transition: opacity 0.8s ease 0.3s, transform 0.8s ease 0.3s;
    }
    .cta-desc {
        font-size: 16px;
        line-height: 1.6;
        margin-bottom: 20px;
        color: rgba(0,0,0,0.8);
        opacity: 0;
        transform: translateX(50px);
        transition: opacity 0.8s ease 0.4s, transform 0.8s ease 0.4s;
    }
    .cta-tagline {
        font-size: 20px;
        font-weight: 700;
        color: #000000;
        margin: 0;
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.8s ease 0.5s, transform 0.8s ease 0.5s;
    }
    
    .cta-animate-active .cta-title,
    .cta-animate-active .cta-lead,
    .cta-animate-active .cta-subtitle,
    .cta-animate-active .cta-desc,
    .cta-animate-active .cta-tagline {
        opacity: 1;
        transform: translate(0, 0);
    }

    .btn-black {
        background-color: #000000;
        color: #ffffff !important;
        border: 2px solid #000000;
        border-radius: 30px;
        padding: 16px 40px;
        font-weight: 700;
        text-transform: uppercase;
        font-size: 16px;
        display: inline-block;
        text-decoration: none;
        transition: all 0.3s ease;
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.8s ease 0.4s, transform 0.8s ease 0.4s, background-color 0.3s, box-shadow 0.3s;
    }
    .cta-animate-active .btn-black {
        opacity: 1;
        transform: translate(0, 0);
    }
    .btn-black:hover {
        background-color: #333333;
        border-color: #333333;
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.2);
    }

    /* --- 14. REWARDS GRID SECTION --- */
    .rewards-grid-section {
        margin-top: 100px;
        padding: 0 40px 60px 40px;
        width: 100%;
        max-width: 1400px;
        margin-left: auto;
        margin-right: auto;
    }

    .rewards-title-wrapper {
        text-align: center;
        margin-bottom: 40px;
    }

    .rewards-main-title {
        font-size: clamp(32px, 5vw, 48px);
        font-weight: 900;
        color: var(--text-primary);
        margin: 0;
        text-transform: uppercase;
        letter-spacing: -1px;
    }

    .rewards-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 16px;
        padding: 0;
    }

    .reward-box {
        background: var(--widget-bg);
        border: 1px solid var(--border-faint);
        border-radius: 8px;
        padding: 20px;
        text-align: center;
        transition: transform 0.2s, box-shadow 0.2s, border-color 0.2s;
        display: flex;
        flex-direction: column;
        justify-content: center;
        min-height: 140px;
        backdrop-filter: blur(10px);
    }

    .reward-box:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 15px rgba(243, 186, 47, 0.15);
        border-color: var(--accent-gold);
    }

    .reward-percent {
        font-size: clamp(24px, 5vw, 28px);
        font-weight: 800;
        color: var(--accent-gold);
        margin-bottom: 8px;
        line-height: 1;
    }

    .reward-amount {
        font-size: 15px;
        color: var(--text-primary);
        font-weight: 600;
        line-height: 1.4;
        margin-bottom: 6px;
        font-family: 'Inter', sans-serif;
    }

    .reward-label {
        font-size: 12px;
        color: var(--text-secondary);
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    /* --- 15. ABOUT SECTION STYLES --- */
    .about-section {
        width: 100%;
        max-width: 1400px;
        margin: 0 auto 20px auto; 
        padding: 0 40px;
    }
    
    .about-title-wrapper {
        text-align: center;
        margin-bottom: 40px;
    }
    .about-main-title {
        font-size: clamp(32px, 5vw, 48px);
        font-weight: 900;
        color: var(--text-primary);
        margin: 0;
        text-transform: uppercase;
        letter-spacing: -1px;
    }

    .about-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 30px;
        margin-bottom: 40px;
    }

    .about-card {
        background: var(--widget-bg);
        border: 1px solid var(--border-faint);
        border-radius: 16px;
        padding: 30px;
        backdrop-filter: blur(10px);
        color: var(--text-primary);
    }
    
    /* Mission Card Specifics (White Background) */
    .about-card.mission-card {
        background: #ffffff;
        color: #000000;
        position: relative; /* Context for pseudo-element */
        overflow: hidden;
    }
    /* Trust Wallet Logo as Watermark - UPDATED SVG & OPACITY */
    .about-card.mission-card::before {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 80%;
        height: 80%;
        background-image: url('https://trustwallet.com/_next/static/media/raw.4edbb099.svg');
        background-repeat: no-repeat;
        background-position: center;
        background-size: contain;
        opacity: 0.2; /* Visible but watermarked */
        pointer-events: none;
        z-index: 0;
    }
    /* Ensure text is above the watermark */
    .about-card.mission-card h3,
    .about-card.mission-card p,
    .about-card.mission-card strong {
        color: #000000;
        position: relative;
        z-index: 1;
    }

    /* Credential Card Specifics */
    .about-card h3 {
        margin-top: 0;
        margin-bottom: 20px;
        font-size: 24px;
        color: var(--accent-gold);
    }
    
    .about-card.mission-card h3 {
        color: #000000;
    }

    .about-card p {
        line-height: 1.6;
        margin-bottom: 15px;
        color: var(--text-secondary);
    }
    .about-card strong {
        color: var(--text-primary);
    }

    .benefits-list {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }
    .benefit-box {
        display: flex;
        gap: 15px;
        align-items: flex-start;
    }
    /* UPDATED: Clean Icon Style (No border/bg) */
    .benefit-icon {
        flex-shrink: 0;
        width: 40px;
        height: 40px;
        background: transparent;
        border-radius: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        border: none;
    }
    .benefit-text h4 {
        margin: 0 0 5px 0;
        color: var(--text-primary);
        font-size: 16px;
        font-weight: 700;
    }
    .benefit-text p {
        margin: 0;
        font-size: 14px;
        color: var(--accent-gold) !important;
        line-height: 1.4;
    }

    /* --- 16. PRC CREDENTIAL BOXES --- */
    .prc-container {
        width: 100%;
        max-width: 1400px;
        margin: 0 auto;
        padding: 0 40px 40px 40px; 
    }

    .prc-header {
        text-align: center;
        margin-bottom: 40px;
    }
    
    .prc-title {
        font-size: clamp(32px, 5vw, 48px);
        font-weight: 900;
        color: var(--text-primary);
        letter-spacing: -1px;
        margin: 0;
        text-transform: uppercase;
    }
    .prc-subtitle {
        font-size: 18px;
        color: var(--text-secondary);
        margin-top: 10px;
        max-width: 800px;
        margin-left: auto;
        margin-right: auto;
        line-height: 1.6;
    }

    .prc-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
    }

    .prc-card {
        background: var(--widget-bg);
        border: 1px solid var(--border-faint);
        border-radius: 12px;
        padding: 25px;
        min-height: 180px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: center;
        text-align: center;
        transition: transform 0.3s, box-shadow 0.3s, border-color 0.3s;
        cursor: pointer;
        position: relative;
        overflow: hidden;
        backdrop-filter: blur(10px);
    }

    .prc-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(243, 186, 47, 0.15);
        border-color: var(--accent-gold);
    }
    
    .prc-card::before {
        content: 'VIEW DETAILS';
        position: absolute;
        bottom: -40px;
        left: 0;
        width: 100%;
        padding: 8px 0;
        background: var(--accent-gold);
        color: #000000;
        font-size: 12px;
        font-weight: 700;
        transition: bottom 0.3s ease-out;
        letter-spacing: 1px;
    }
    .prc-card:hover::before {
        bottom: 0;
    }

    .prc-card-icon-svg {
        width: 48px;
        height: 48px;
        margin-bottom: 15px;
        fill: none;
        stroke: var(--accent-gold);
        stroke-width: 2;
        stroke-linecap: round;
        stroke-linejoin: round;
    }

    .prc-card-title {
        font-size: 18px;
        font-weight: 700;
        color: var(--text-primary);
        margin-bottom: 10px;
    }

    .prc-card-badge {
        font-size: 11px;
        font-weight: 700;
        color: #000000;
        background: var(--accent-gold);
        padding: 4px 10px;
        border-radius: 4px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    /* PRC Modal Styles */
    .prc-modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.85);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 10000;
        opacity: 0;
        transition: opacity 0.3s ease-in-out;
        backdrop-filter: blur(5px);
    }
    .prc-modal-overlay.prc-active {
        display: flex;
        opacity: 1;
    }
    .prc-modal-content {
        background: var(--popup-bg);
        border: 1px solid var(--border-faint);
        border-radius: 12px;
        padding: 30px;
        max-width: 650px;
        width: 90%;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
        position: relative;
        transform: scale(0.9);
        transition: transform 0.3s ease-in-out;
        color: var(--text-primary);
    }
    .prc-modal-overlay.prc-active .prc-modal-content {
        transform: scale(1);
    }
    .prc-modal-close {
        position: absolute;
        top: 15px;
        right: 15px;
        background: none;
        border: none;
        font-size: 24px;
        color: var(--text-secondary);
        cursor: pointer;
        transition: color 0.2s;
        line-height: 1;
    }
    /* FIX: Prevent Pink Hover */
    .prc-modal-close:hover {
        color: var(--accent-gold);
    }
    .prc-modal-title {
        font-size: clamp(22px, 4vw, 30px);
        font-weight: 700;
        color: var(--accent-gold);
        margin-bottom: 15px;
    }
    .prc-modal-body p {
        margin-bottom: 15px;
        font-size: 16px;
        line-height: 1.7;
        color: var(--text-primary);
    }
    .prc-modal-link-box {
        margin-top: 25px;
        padding: 15px;
        background: rgba(255,255,255,0.05);
        border: 1px solid var(--border-faint);
        border-radius: 8px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .prc-modal-link-box a {
        color: var(--accent-gold);
        font-weight: 600;
        text-decoration: none;
        transition: color 0.2s;
    }
    .prc-modal-link-box a:hover {
        color: #ffffff;
        text-decoration: underline;
    }
    .prc-modal-link-label {
        font-size: 14px;
        color: var(--text-secondary);
        margin-right: 10px;
    }

    /* --- WELCOME POPUP STYLES --- */
    .welcome-modal-overlay {
        position: fixed;
        top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.85);
        z-index: 11000;
        display: none; /* Controlled by JS */
        justify-content: center;
        align-items: center;
        backdrop-filter: blur(8px);
    }
    .welcome-modal-content {
        position: relative;
        background-color: var(--menu-bg);
        width: 90%; max-width: 600px;
        padding: 40px;
        border-radius: 16px;
        border: 1px solid var(--border-faint);
        text-align: center;
        overflow: hidden;
        color: var(--text-primary);
        box-shadow: 0 20px 60px rgba(0,0,0,0.6);
    }
    /* Background Image Faint - UPDATED OPACITY */
    .welcome-modal-bg {
        position: absolute;
        top: 0; left: 0; width: 100%; height: 100%;
        background-image: url('https://trustwallet.com/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Fimage.93518954.png&w=3840&q=75');
        background-size: cover;
        background-position: center;
        opacity: 0.25; /* Increased Brightness */
        z-index: 0;
        pointer-events: none;
    }
    .welcome-modal-inner {
        position: relative; z-index: 1;
    }
    .welcome-close-btn {
        position: absolute;
        top: 15px; right: 15px;
        background: transparent; border: none;
        color: var(--text-secondary);
        font-size: 24px; cursor: pointer;
        z-index: 2; transition: color 0.2s;
    }
    /* FIX: Prevent Pink Hover */
    .welcome-close-btn:hover { color: var(--accent-gold); }

    .welcome-title {
        font-size: 28px; font-weight: 800;
        color: var(--accent-gold);
        margin-bottom: 10px;
        text-transform: uppercase;
        letter-spacing: -0.5px;
    }
    .welcome-subtitle {
        font-size: 18px; font-weight: 600;
        color: var(--text-primary);
        margin-bottom: 25px;
    }
    .welcome-text {
        font-size: 15px; line-height: 1.6;
        color: var(--text-secondary);
        margin-bottom: 20px;
    }
    .welcome-features {
        display: flex; flex-direction: column; gap: 10px;
        margin-bottom: 25px;
        align-items: center;
    }
    .welcome-feature-item {
        font-size: 15px; font-weight: 600;
        color: var(--text-primary);
        display: flex; align-items: center; gap: 8px;
    }
    .welcome-footer {
        font-size: 14px; color: var(--text-secondary);
        border-top: 1px solid var(--border-faint);
        padding-top: 20px;
        font-style: italic;
    }

    /* --- LIVE SUPPORT WIDGET STYLES (UPDATED Logic) --- */
    .live-support-widget {
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 9999;
        display: none; /* Controlled by JS */
        flex-direction: column;
        align-items: flex-end; /* Align bubble to right */
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.5s ease, transform 0.5s ease;
    }
    
    .live-support-widget.active {
        opacity: 1;
        transform: translateY(0);
    }
    
    /* Message Bubble OUTSIDE box */
    .support-bubble-outside {
        background: #ffffff;
        color: #000000;
        padding: 10px 15px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 700;
        margin-bottom: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        position: relative;
        max-width: 200px;
        text-align: center;
        animation: bubbleFloat 3s ease-in-out infinite;
    }
    /* Arrow for bubble */
    .support-bubble-outside::after {
        content: '';
        position: absolute;
        bottom: -6px;
        right: 20px;
        width: 0; height: 0;
        border-left: 6px solid transparent;
        border-right: 6px solid transparent;
        border-top: 6px solid #ffffff;
    }
    
    @keyframes bubbleFloat {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-5px); }
    }

    .support-box-inner {
        width: auto;
        max-width: 320px;
        background: var(--accent-gold);
        border: 1px solid rgba(0,0,0,0.1);
        border-radius: 12px;
        padding: 15px 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.4);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: flex-start;
        backdrop-filter: blur(10px);
        position: relative;
    }

    @keyframes pulse-green {
        0% { transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.7); }
        70% { transform: scale(1);
        box-shadow: 0 0 0 6px rgba(34, 197, 94, 0); }
        100% { transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(34, 197, 94, 0); }
    }
    
    .status-dot {
        width: 10px;
        height: 10px;
        background-color: #15803d; /* Dark Green */
        border-radius: 50%;
        margin-right: 8px;
        animation: pulse-green 2s infinite;
    }
    
    .support-header-row {
        display: flex;
        align-items: center;
        margin-bottom: 2px;
    }

    .support-close-btn {
        position: absolute;
        top: 5px;
        right: 8px;
        background: none;
        border: none;
        color: rgba(0,0,0,0.6);
        font-size: 20px;
        cursor: pointer;
        line-height: 1;
        padding: 5px;
        transition: color 0.2s;
        z-index: 2;
    }
    /* FIX: Prevent Pink Hover */
    .support-close-btn:hover { color: #000000; }

    .support-content {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .support-title {
        font-size: 14px;
        font-weight: 800;
        color: #000000;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .support-link-overlay {
        position: absolute;
        top: 0; left: 0; width: 100%; height: 100%;
        z-index: 1;
        cursor: pointer;
    }

  /* Mobile Adjustments */
  @media (max-width: 576px) {
    .global-map-section { 
        padding: 0 20px !important;
        margin-top: -30px !important;
        padding-top: 0 !important;
    }
    .map-wrapper { height: 450px; }
    
    .map-header { padding: 15px !important;
    min-height: auto; }
    .map-title { font-size: 24px !important; margin-bottom: 5px; }

    .global-stats-row {
        margin-top: -50px;
        flex-direction: row !important;
        gap: 15px;
        justify-content: space-between;
    }
    .stat-number { font-size: 24px; }
    .stat-label { font-size: 12px; }
    
    .timeline-section { padding: 0 20px 40px 20px; }
    .timeline-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
    }
    .timeline-box { min-height: 100px; padding: 12px 8px; }

    .rewards-grid-section { 
        margin-top: 60px;
        padding: 0 20px 50px 20px !important;
    }
    .rewards-grid {
        grid-template-columns: repeat(3, 1fr) !important;
        gap: 5px;
    }
    .reward-box { 
        min-height: 90px; 
        padding: 8px 5px;
    }
    .reward-percent { font-size: 16px; margin-bottom: 4px; }
    .reward-amount { font-size: 10px; margin-bottom: 4px; }
    .reward-label { font-size: 8px; }

    .cta-section-wrapper { padding: 50px 20px; }
    .cta-grid {
        grid-template-columns: 1fr;
        gap: 30px;
        text-align: left;
    }
    .cta-title { 
        font-size: 36px; 
        line-height: 1.1;
        text-align: left;
    }
    .cta-lead { font-size: 16px; text-align: left; margin-bottom: 20px; }
    .cta-subtitle { font-size: 24px;
    text-align: left; }
    .cta-desc, .cta-tagline { text-align: left; }
    
    .cta-left {
        display: flex;
        flex-direction: column;
        align-items: flex-end; 
    }
    .btn-black { 
        width: auto;
        padding: 12px 25px; 
        font-size: 14px; 
        margin-top: 10px;
    }
    
    /* Updated Hero Mobile */
    .hero-brand-title {
        font-size: 42px;
    }
    .hero-subtitle {
        font-size: 18px;
    }
    .hero-replacement-container {
        min-height: 200px;
        margin-bottom: 20px;
    }

    .about-section {
        margin-top: 0;
        margin-bottom: 0 !important; 
        padding: 0 20px 20px 20px !important;
    }
    .about-grid {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    .about-card {
        padding: 20px;
    }

    .prc-container {
        margin-top: 0 !important;
        padding: 10px 20px 50px 20px !important;
    }
    .prc-grid {
        grid-template-columns: repeat(2, 1fr) !important;
        gap: 10px;
    }
    .prc-card {
        min-height: 140px;
        padding: 15px;
    }
    .prc-card-icon-svg {
        width: 36px;
        height: 36px;
        margin-bottom: 10px;
    }
    .prc-card-title {
        font-size: 14px;
        margin-bottom: 8px;
    }
    .prc-card-badge {
        font-size: 9px;
        padding: 3px 6px;
    }

    /* Smaller Welcome Modal for Mobile */
    .welcome-modal-content {
        width: 85%;
        max-width: 320px;
        padding: 25px 20px;
        max-height: 80vh;
        overflow-y: auto;
    }
    .welcome-title { font-size: 20px; margin-bottom: 8px; }
    .welcome-subtitle { font-size: 15px; margin-bottom: 15px; }
    .welcome-text { font-size: 13px; line-height: 1.5; }
    .welcome-features { gap: 6px; margin-bottom: 15px; }
    .welcome-feature-item { font-size: 13px; }
    .welcome-footer { font-size: 11px; padding-top: 15px; }
    .welcome-close-btn { top: 10px; right: 10px; font-size: 20px; }
  }
  
  @media (min-width: 769px) and (max-width: 1200px) {
    .timeline-grid { grid-template-columns: repeat(4, 1fr); }
    .rewards-grid { grid-template-columns: repeat(3, 1fr); }
  }
  
  @media (max-width: 1024px) {
      .dual-info-wrapper { flex-direction: column; gap: 40px; }
      .info-grid.text-only { padding: 0; }
  }

  @media (max-width: 768px) {
    * { backdrop-filter: none !important; }
    .cube-glow-background { display: none !important; } 
    .info-popup, .cube-face-element, .bnb-widget-wrapper, .calc-widget-wrapper, .timeline-box, .modal-content, .reward-box, .about-card, .prc-card, .prc-modal-content { background: #000000 !important;
    box-shadow: none !important; }
    
    /* Support widget mobile */
    .support-box-inner { background: var(--accent-gold) !important; }
    
    .pri-master-wrapper.light-theme .info-popup,
    .pri-master-wrapper.light-theme .cube-face-element,
    .pri-master-wrapper.light-theme .bnb-widget-wrapper,
    .pri-master-wrapper.light-theme .calc-widget-wrapper,
    .pri-master-wrapper.light-theme .timeline-box,
    .pri-master-wrapper.light-theme .modal-content,
    .pri-master-wrapper.light-theme .reward-box,
    .pri-master-wrapper.light-theme .about-card,
    .pri-master-wrapper.light-theme .prc-card,
    .pri-master-wrapper.light-theme .prc-modal-content { background: #ffffff !important; }
    
    .about-card.mission-card { background: #ffffff !important; }

    .pri-master-wrapper.light-theme .cube-face-image { filter: invert(1); }

    .pri-header { padding: 15px 20px; }
    .header-logo { height: 40px; }
    
    .hero-actions { display: none !important; }
    
    .hero-section { 
        min-height: 100vh;
        padding-top: 100px !important; 
        padding-bottom: 50px !important; 
        justify-content: flex-start; display: flex;
        flex-direction: column;
        padding-left: 20px !important; padding-right: 20px !important;
    }
    .hero-content { padding: 0 !important; }
    
    .cube-slider-container { margin-top: 20px !important;
    margin-bottom: 0px !important; height: 280px !important;
      perspective: 800px; }
    .cube-3d-element { width: 220px !important; height: 220px !important; } 
    .cube-face-element { 
        width: 220px !important;
        height: 220px !important;
        border: 1px solid rgba(255, 255, 255, 0.15) !important;
    }
    .cube-face-front { transform: rotateY(0deg) translateZ(110px) !important; }
    .cube-face-back { transform: rotateY(180deg) translateZ(110px) !important; }
    .cube-face-right { transform: rotateY(90deg) translateZ(110px) !important; }
    .cube-face-left { transform: rotateY(-90deg) translateZ(110px) !important; }
    .cube-face-top { transform: rotateX(90deg) translateZ(110px) !important; }
    .cube-face-bottom { transform: rotateX(-90deg) translateZ(110px) !important; }
    
    .bnb-section-wrapper, 
    .calc-section-wrapper,
    .info-section-wrapper,
    .timeline-section,
    .rewards-grid-section,
    .about-section { 
        padding: 0px 20px 50px 20px !important;
    }
    .info-section-wrapper { display: flex; flex-direction: column; }
    
    .bnb-section-wrapper {
        margin-top: -40px !important;
    }
    
    .bnb-widget-wrapper, .calc-widget-wrapper { 
        max-width: 100%;
        padding: 20px; 
    }

    #bnb-data { grid-template-columns: 1fr 1fr; gap: 10px; }
    .bnb-main-price { grid-column: 1 / -1; padding: 15px; }
    #current-price { font-size: 28px; }
    .bnb-stat-item { padding: 10px; }
    .stat-value { font-size: 14px; }
    .bnb-changes-container { flex-direction: column; gap: 10px; }
    .change-group { display: flex; justify-content: space-between;
    width: 100%; border-bottom: 1px solid var(--w-border); padding-bottom: 5px; }
    .change-group:last-child { border-bottom: none; padding-bottom: 0; }
    
    .calc-grid { grid-template-columns: 1fr; gap: 20px; }

    .info-grid { 
        margin-bottom: 50px !important;
        flex-direction: column-reverse !important; 
        gap: 30px; 
    }
    .info-grid.reverse { flex-direction: column-reverse !important; }
    
    .dual-info-wrapper { 
        gap: 25px !important;
        margin: 0 auto 30px auto;
        margin-bottom: 10px !important; 
    }
    
    .info-grid.text-only { width: 100%;
    margin-bottom: 25px !important; }
    
    .info-grid.text-only .info-title { 
        text-align: left;
        padding: 0; 
    }
    
    .info-item { font-size: 16px !important;
    gap: 12px !important; }
    .info-icon { width: 20px !important; height: 20px !important; min-width: 20px !important;
    margin-top: 2px !important; }
    
    .info-grid:not(.reverse) .info-image { justify-content: flex-end; }
    .info-grid.reverse .info-image { justify-content: flex-start; }
    
    .info-title { font-size: 28px;
    text-align: left !important; }
    .info-image img { max-width: 230px; }
  }
</style>

<div class="pri-master-wrapper" id="masterWrapper">
  <canvas id="particle-canvas"></canvas>
  
  <header class="pri-header">
      <div class="header-logo">
          <img decoding="async" src="/wp-content/uploads/2025/08/1350-x-100-px.svg" alt="Paul Rice Investment">
      </div>
      <div class="header-controls">
          <button class="theme-toggle-btn" id="themeToggle" aria-label="Toggle Theme">
              <svg class="icon-sun" viewbox="0 0 24 24"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>
              <svg class="icon-moon" viewbox="0 0 24 24"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>
          </button>
          <button class="burger-menu-btn" onclick="toggleMobileMenu()">
              <span class="burger-line"></span><span class="burger-line"></span><span class="burger-line"></span>
          </button>
      </div>
  </header>

  <div class="mobile-menu-overlay" id="mobileMenu">
      <button class="mobile-menu-close" onclick="toggleMobileMenu()">×</button>
      <div class="mobile-menu-items">
        <a href="/dashboard/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
            <span style="color: var(--accent-gold); font-weight: 700;">Get Started</span>
        </a>
        <a href="/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
            <span>Home</span>
        </a>
        <a href="/free-signal/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
            <span>Free Signal</span>
        </a>
        <a href="/why-choose-us/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            <span>Why Choose Us?</span>
        </a>
        <a href="/about-us/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
            <span>About Us</span>
        </a>
        <a href="/our-team/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
            <span>Our Team</span>
        </a>
        <a href="/fca-licensing/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
            <span>FCA Licensing</span>
        </a>
        <a href="/gov-licensing/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
            <span>GOV Licensing</span>
        </a>
        <a href="/market-fundamentals/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
            <span>Market Fundamentals</span>
        </a>
        <a href="/forex-market/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
            <span>Forex Market</span>
        </a>
        <a href="/crypto-market/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"></path><line x1="12" y1="18" x2="12" y2="22"></line><line x1="12" y1="2" x2="12" y2="6"></line></svg>
            <span>Crypto Market</span>
        </a>
        <a href="/live-charts/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
            <span>Live Charts</span>
        </a>
        <a href="/technical-analysis/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline></svg>
            <span>Technical Analysis</span>
        </a>
        <a href="/academi/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>
            <span>Academy</span>
        </a>
        <a href="/demo-trading/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
            <span>Demo Trading</span>
        </a>
        <a href="/faq/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
            <span>FAQ</span>
        </a>
        <a href="https://t.me/prinvesmentbot" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="4"></circle><line x1="4.93" y1="4.93" x2="9.17" y2="9.17"></line><line x1="14.83" y1="14.83" x2="19.07" y2="19.07"></line><line x1="14.83" y1="9.17" x2="19.07" y2="4.93"></line><line x1="14.83" y1="9.17" x2="18.36" y2="5.64"></line><line x1="4.93" y1="19.07" x2="9.17" y2="14.83"></line></svg>
            <span>Support</span>
        </a>
        <a href="/apply-as-trader/" class="mobile-menu-link">
            <svg class="menu-icon-svg" viewbox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
            <span>Apply as Trader</span>
        </a>
      </div>
  </div>

  <div class="hero-section">
    <div class="hero-content">
      <div class="hero-replacement-container">
          <h1 class="hero-brand-title">Paul Rice Investment</h1>
          <p class="hero-subtitle">Where skilled traders and <span class="highlight-text">smart investors</span> connect to create consistent market success.</p>
      </div>
      
      <div class="hero-actions">
        <a href="/dashboard/" class="btn btn-primary">Get Started</a>
        <a href="https://t.me/PAULRICEINVESTMENTPLANNING" class="btn btn-outline">Free Signal</a>
        <a href="https://t.me/prinvesmentbot" class="btn btn-outline">Support</a>
      </div>
    </div>
    <div class="cube-slider-container">
        <div class="cube-glow-background"></div>
        <div class="cube-3d-element">
            <div class="cube-face-element cube-face-front"><img decoding="async" class="cube-face-image" src="/wp-content/uploads/2025/09/2.svg" alt="Partner"></div>
            <div class="cube-face-element cube-face-back"><img decoding="async" class="cube-face-image" src="/wp-content/uploads/2025/09/1.png" alt="Partner"></div>
            <div class="cube-face-element cube-face-right"><img decoding="async" class="cube-face-image" src="/wp-content/uploads/2025/09/2.png" alt="Partner"></div>
            <div class="cube-face-element cube-face-left"><img decoding="async" class="cube-face-image" src="/wp-content/uploads/2025/09/4.png" alt="Partner"></div>
            <div class="cube-face-element cube-face-top"><img decoding="async" class="cube-face-image" src="/wp-content/uploads/2025/09/5.png" alt="Partner"></div>
            <div class="cube-face-element cube-face-bottom"><img decoding="async" class="cube-face-image" src="/wp-content/uploads/2025/09/6.png" alt="Partner"></div>
        </div>
    </div>
  </div>

  <div class="bnb-section-wrapper">
    <div class="bnb-widget-wrapper">
      <div class="bnb-header">
        <h2 class="bnb-title">
            <img decoding="async" src="https://assets.coingecko.com/coins/images/825/small/binance-coin-logo.png" alt="BNB" style="width: 24px; height: 24px;">
            BNB Statistics
        </h2>
        <div id="loading" class="bnb-loading">Loading market data...</div>
      </div>
      
      <div id="bnb-data">
        <div class="bnb-main-price">
          <div class="price-label">Current Price</div>
          <div id="current-price"></div>
        </div>
        <div class="bnb-stat-item">
            <div class="stat-label">Market Rank</div>
            <div id="market-rank" class="stat-value"></div>
        </div>
        <div class="bnb-stat-item">
            <div class="stat-label">Market Cap</div>
            <div id="market-cap" class="stat-value"></div>
        </div>
        <div class="bnb-stat-item">
            <div class="stat-label">24h Volume</div>
            <div id="volume-24h" class="stat-value"></div>
        </div>
        <div class="bnb-stat-item">
            <div class="stat-label">Circulating Supply</div>
            <div id="circulating-supply" class="stat-value"></div>
        </div>
        <div class="bnb-stat-item">
            <div class="stat-label">Total Supply</div>
            <div id="total-supply" class="stat-value"></div>
        </div>
        <div class="bnb-stat-item">
            <div class="stat-label">24h High / Low</div>
            <div id="high-low-24h" class="stat-value"></div>
        </div>
        <div class="bnb-stat-item">
            <div class="stat-label">All-Time High</div>
            <div id="ath" class="stat-value"></div>
        </div>
        <div class="bnb-stat-item">
            <div class="stat-label">All-Time Low</div>
            <div id="atl" class="stat-value"></div>
        </div>
        <div class="bnb-changes-container">
            <div class="change-group">
                <span class="change-label">24h Change</span>
                <span id="change-24h" class="change-val"></span>
            </div>
            <div class="change-group">
                <span class="change-label">7d Change</span>
                <span id="change-7d" class="change-val"></span>
            </div>
             <div class="change-group">
                <span class="change-label">30d Change</span>
                <span id="change-30d" class="change-val"></span>
            </div>
        </div>
      </div>
      <div id="error-message"></div>
      <div class="last-updated">
        Last updated: <span id="last-updated"></span>
      </div>
    </div>
  </div>

  <div class="calc-section-wrapper">
    <div class="calc-widget-wrapper">
        <div class="calc-header">
            <h2 class="calc-title">Investment Calculator</h2>
        </div>
        <div class="calc-grid">
            <div class="calc-inputs">
                <div class="input-group">
                    <label class="input-label">Investment Amount (USDT)</label>
                    <input type="number" id="calc-amount" class="calc-input-field" placeholder="Enter amount (e.g. 500)" min="10">
                </div>
            </div>
            <div class="calc-results">
                <div class="result-row">
                    <span class="result-label">Daily Profit Rate</span>
                    <span id="calc-rate-display" class="result-value highlight-blue">0%</span>
                </div>
                <div class="result-row">
                    <span class="result-label">Daily Profit</span>
                    <span id="calc-daily-profit" class="result-value">$0.00</span>
                </div>
                <div class="result-row">
                    <span class="result-label">Monthly Profit</span>
                    <span id="calc-monthly-profit" class="result-value highlight">$0.00</span>
                </div>
            </div>
        </div>
    </div>
  </div>

  <div class="info-section-wrapper">
      
      <div class="info-grid">
          <div class="info-text">
              <h2 class="info-title">Why Hire a Trader?</h2>
              <ul class="info-list">
                  <li class="info-item">
                     <svg class="info-icon" viewbox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                      <span><strong>Leverage Expertise.</strong><br>Benefit from vetted professionals who have passed our rigorous evaluations.</span>
                  </li>
                  <li class="info-item">
                       <svg class="info-icon" viewbox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>
                      <span><strong>Eliminate Mistakes.</strong><br>Avoid the emotional trading and costly errors common among novice investors.</span>
                  </li>
                  <li class="info-item">
                         <svg class="info-icon" viewbox="0 0 24 24"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline></svg>
                      <span><strong>Save Your Time.</strong><br>Focus on your life while experts monitor the 24/7 global markets for you.</span>
                  </li>
                  <li class="info-item">
                      <svg class="info-icon" viewbox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
                      <span><strong>Maximize Opportunity.</strong><br>Gain access to diverse strategies across multiple markets (Crypto, Forex, etc.) determined by your capital.</span>
                  </li>
              </ul>
          </div>
          <div class="info-image">
              <img decoding="async" src="https://paulriceinvestment.com/wp-content/uploads/2025/11/SA.png" alt="Why Hire a Trader">
          </div>
      </div>

      <div class="dual-info-wrapper">
          <div class="info-grid text-only">
              <div class="info-text">
                  <h2 class="info-title">Truth is...<br><span class="highlight-word">Trading is not easy</span></h2>
                  <ul class="info-list">
                      <li class="info-item">
                           <svg class="info-icon" viewbox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                          <span>Studying the market takes time</span>
                      </li>
                      <li class="info-item">
                          <svg class="info-icon" viewbox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>
                          <span>Building and maintaining a trading strategy is hard</span>
                      </li>
                      <li class="info-item">
                          <svg class="info-icon" viewbox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                          <span>
                                That’s why only 11–26% of individual investors end up winning.
                              <span class="tooltip-trigger" onclick="toggleInfoPopup('popup1')">
                                  <svg viewbox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
                              </span>
                          </span>
                      </li>
                  </ul>
              </div>
          </div>

          <div class="info-grid text-only">
            <div class="info-text">
                  <h2 class="info-title">Stop Trading Alone.<br><span class="highlight-word">Hire a Pro.</span></h2>
                  <ul class="info-list">
                      <li class="info-item">
                          <svg class="info-icon" viewbox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                          <span>Don't risk your capital and time</span>
                      </li>
                      <li class="info-item">
                           <svg class="info-icon" viewbox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                          <span>We connect you to vetted traders</span>
                      </li>
                       <li class="info-item">
                          <svg class="info-icon" viewbox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                          <span>
                                Verified &amp; Regulated Excellence
                              <span class="tooltip-trigger" onclick="toggleInfoPopup('popup2')">
                                  <svg viewbox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
                              </span>
                          </span>
                      </li>
                  </ul>
              </div>
          </div>
      </div>
  </div>
  
  <div class="global-map-section container">
    <div class="map-header">
        <h2 class="map-title">Our Global Footprint</h2>
        <p class="map-subtitle">Connecting investors and verified traders across the world, our performance speaks for itself.</p>
    </div>
    <div class="map-wrapper">
        <div id="globe-viz"></div>
    </div>
    <div class="global-stats-row">
        <div class="stat-item">
            <span class="stat-number">150+</span>
            <span class="stat-label">Countries</span>
        </div>
        <div class="stat-item">
            <span class="stat-number">800000+</span>
            <span class="stat-label">Accounts</span>
        </div>
        <div class="stat-item">
            <span class="stat-number">18000+</span>
            <span class="stat-label">Trader</span>
        </div>
    </div>
  </div>
  
  <div class="timeline-section">
    <div class="timeline-header">
        <h2 class="timeline-title">From 2013 to Present</h2>
    </div>
    <div class="timeline-grid" id="timelineGrid">
        </div>
  </div>

  <div class="cta-section-wrapper" id="ctaSection">
      <div class="cta-grid">
          <div class="cta-left">
              <h2 class="cta-title">Don't miss the opportunity to earn income!</h2>
              <p class="cta-lead">We are constantly monitoring global markets, hire a professional trader and start earning profit immediately. While you enjoy freedom</p>
              <a href="/dashboard/" class="btn-black">GET STARTED</a>
          </div>
          <div class="cta-right">
              <h3 class="cta-subtitle">Earn income in the Crypto and Forex markets.</h3>
              <p class="cta-desc">Let our team of professional analysts and certified traders manage your wealth. We are continually researching projects, identifying new opportunities, and implementing diverse, data-driven strategies for maximum returns.</p>
              <p class="cta-tagline">Maintain your life. Reach your goals.</p>
          </div>
      </div>
  </div>

  <div class="rewards-grid-section container">
    <div class="rewards-title-wrapper">
        <h2 class="rewards-main-title">Trader Recruitment Plans</h2>
    </div>

    <div class="rewards-grid">
        <div class="reward-box">
            <div class="reward-percent">1%</div>
            <div class="reward-amount">$10 – $149</div>
            <div class="reward-label">Daily Reward</div>
        </div>
        <div class="reward-box">
            <div class="reward-percent">1.1%</div>
            <div class="reward-amount">$150 – $299</div>
            <div class="reward-label">Daily Reward</div>
        </div>
        <div class="reward-box">
            <div class="reward-percent">1.2%</div>
            <div class="reward-amount">$300 – $499</div>
            <div class="reward-label">Daily Reward</div>
        </div>
        <div class="reward-box">
            <div class="reward-percent">1.3%</div>
            <div class="reward-amount">$500 – $599</div>
            <div class="reward-label">Daily Reward</div>
        </div>
        <div class="reward-box">
            <div class="reward-percent">1.4%</div>
            <div class="reward-amount">$600 – $699</div>
            <div class="reward-label">Daily Reward</div>
        </div>
        <div class="reward-box">
            <div class="reward-percent">1.5%</div>
            <div class="reward-amount">$700 – $799</div>
            <div class="reward-label">Daily Reward</div>
        </div>
        <div class="reward-box">
            <div class="reward-percent">2%</div>
            <div class="reward-amount">$800 – $1,499</div>
            <div class="reward-label">Daily Reward</div>
        </div>
        <div class="reward-box">
            <div class="reward-percent">2.5%</div>
            <div class="reward-amount">$1,500 – $1,999</div>
            <div class="reward-label">Daily Reward</div>
        </div>
        <div class="reward-box">
            <div class="reward-percent">3%</div>
            <div class="reward-amount">$2,000 – $2,999</div>
            <div class="reward-label">Daily Reward</div>
        </div>
        <div class="reward-box">
            <div class="reward-percent">5%</div>
            <div class="reward-amount">$3,000 – $3,999</div>
            <div class="reward-label">Daily Reward</div>
        </div>
        <div class="reward-box">
            <div class="reward-percent">6%</div>
            <div class="reward-amount">$4,000 – $4,999</div>
            <div class="reward-label">Daily Reward</div>
        </div>
        <div class="reward-box">
            <div class="reward-percent">7%</div>
            <div class="reward-amount">$5,000 – $5,999</div>
            <div class="reward-label">Daily Reward</div>
        </div>
        <div class="reward-box">
            <div class="reward-percent">8%</div>
            <div class="reward-amount">$6,000 – $6,999</div>
            <div class="reward-label">Daily Reward</div>
        </div>
        <div class="reward-box">
            <div class="reward-percent">10%</div>
            <div class="reward-amount">$7,000 and above</div>
            <div class="reward-label">Daily Reward</div>
        </div>
    </div>
  </div>

  <div class="about-section container">
    <div class="about-title-wrapper">
        <h2 class="about-main-title">About PAUL RICE INVESTMENT</h2>
    </div>

    <div class="about-grid">
        <div class="about-card mission-card">
            <h3>Our Mission &amp; History</h3>
            <p>Founded in 2013, <strong>PAUL RICE INVESTMENT PLANNING LIMITED</strong> has been a trusted name in the financial sector for over a decade. We operate across multiple financial fields, dedicated to providing secure, transparent, and innovative investment solutions for our clients worldwide.</p>
            <p>Our mission is to democratize access to advanced financial opportunities, such as investing in financial markets, backed by years of industry expertise and an steadfast commitment to reliability.</p>
        </div>

        <div class="about-card">
            <h3>Our Credentials</h3>
            <div class="benefits-list">
                <div class="benefit-box">
                    <div class="benefit-icon">
                        <img decoding="async" src="https://paulriceinvestment.com/wp-content/uploads/2025/11/dice3.png" alt="FCA" style="width: 24px; height: 24px;">
                    </div>
                    <div class="benefit-text">
                        <h4>FCA Licensed</h4>
                        <p>We hold a financial health license from the FCA (Financial Conduct Authority), ensuring compliance and security.</p>
                    </div>
                </div>
                <div class="benefit-box">
                    <div class="benefit-icon">
                        <img decoding="async" src="https://paulriceinvestment.com/wp-content/uploads/2025/11/role-playing.png" alt="Verified" style="width: 24px; height: 24px;">
                    </div>
                    <div class="benefit-text">
                        <h4>Verified &amp; Trusted</h4>
                        <p>Our operations are verified across 147+ financial platforms, proving our legitimacy and reach.</p>
                    </div>
                </div>
                <div class="benefit-box">
                    <div class="benefit-icon">
                        <img decoding="async" src="https://paulriceinvestment.com/wp-content/uploads/2025/11/d20.png" alt="Record" style="width: 24px; height: 24px;">
                    </div>
                    <div class="benefit-text">
                        <h4>Flawless Record</h4>
                        <p>We maintain a perfect operational record with zero warnings or violations registered since 2013.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>

  <div class="prc-container">
    <div class="prc-header">
        <h2 class="prc-title">Professional Credibility &amp; Verification</h2>
        <p class="prc-subtitle">Verifying our commitment to transparency, regulatory compliance, and industry excellence.</p>
    </div>

    <div class="prc-grid" id="prcGrid">
        </div>
  </div>

  <div class="popup-overlay-bg" id="popupOverlay" onclick="closeAllPopups()"></div>
  
  <div class="info-popup" id="popup1">
      <div class="popup-close-icon" onclick="closeAllPopups()">×</div>
      <p class="popup-text">Between 74-89% of retail investor accounts lose money when trading CFDs.</p>
      <span class="popup-source">(source: ESMA)</span>
  </div>

  <div class="info-popup" id="popup2">
      <div class="popup-close-icon" onclick="closeAllPopups()">×</div>
      <p class="popup-text">We have been operating in the global market for over 13 years, with official registration in the UK and full financial approval from the FCA, ensuring maximum transparency and security for your investment.</p>
  </div>
  
  <div id="timelineModalOverlay" class="modal-overlay" onclick="closeTimelineModal(event)">
     <div class="modal-content" onclick="event.stopPropagation()">
          <button class="modal-close" onclick="closeTimelineModal(event)">×</button>
          <h3 class="modal-title" id="modalTitle"></h3>
          <div class="modal-subtitle" id="modalSubtitle"></div>
          <div class="modal-body" id="modalBody"></div>
          <div class="modal-link-box" id="modalLinkBox">
              <!-- Content injected by JS -->
          </div>
      </div>
  </div>

  <div id="prcModalOverlay" class="prc-modal-overlay" onclick="prcCloseModal(event)">
    <div class="prc-modal-content" onclick="event.stopPropagation()">
        <button class="prc-modal-close" onclick="prcCloseModal(event)">×</button>
        <h3 class="prc-modal-title" id="prcModalTitle"></h3>
        <div class="prc-modal-body" id="prcModalBody"></div>
        <div class="prc-modal-link-box">
            <span class="prc-modal-link-label">Official Link:</span>
            <a href="#" id="prcModalLink" target="_blank">View External Verification</a>
        </div>
    </div>
  </div>

  <div id="welcomeModal" class="welcome-modal-overlay">
      <div class="welcome-modal-content">
          <div class="welcome-modal-bg"></div>
          <button class="welcome-close-btn" onclick="closeWelcomeModal()">×</button>
          <div class="welcome-modal-inner">
              <h2 class="welcome-title">Welcome to Paul Rice Investment</h2>
              <div class="welcome-subtitle">Your Security, Our Priority</div>
              <p class="welcome-text">We’re glad to have you here.<br>Our platform now operates with enhanced security standards, powered by our latest system upgrade and official integration with Trust Wallet.</p>
              
              <div class="welcome-features">
                  <div class="welcome-feature-item">🔒 Top-tier blockchain protection</div>
                  <div class="welcome-feature-item">🔐 Secure asset management</div>
                  <div class="welcome-feature-item">⚡ Faster &amp; smarter performance</div>
              </div>

              <p class="welcome-text">Enjoy a safer, smoother, and more reliable investment experience, starting now.</p>
              
              <div class="welcome-footer">
                  Paul Rice Investment<br>
                  Where skilled traders and smart investors connect to create consistent market success.
              </div>
          </div>
      </div>
  </div>

  <div id="draggableTw" class="floating-tw-wrapper">
      <div class="floating-tw-icon">
          <a href="/dashboard/" class="tw-click-layer"></a>
          <img decoding="async" src="/wp-content/uploads/2025/11/raw.0acff7b3.svg" alt="Trust Wallet">
      </div>
      <span class="tw-tooltip-float">Get Started</span>
  </div>

  <div class="live-support-widget" id="liveSupportWidget">
      <div class="support-bubble-outside">Need assistance? We are here to help.</div>
      <div class="support-box-inner">
          <button class="support-close-btn" id="closeLiveSupport">×</button>
          <a href="https://t.me/prinvesmentbot" target="_blank" class="support-link-overlay"></a>
          <div class="support-content">
              <div class="support-header-row">
                <div class="status-dot"></div>
                <span class="support-title">Live Support</span>
              </div>
          </div>
      </div>
  </div>

</div>

<script>
  /* --- UI Logic --- */
  function toggleMobileMenu() {
      const menu = document.getElementById('mobileMenu');
      menu.classList.toggle('active');
      document.body.style.overflow = menu.classList.contains('active') ? 'hidden' : 'auto';
  }
  const themeBtn = document.getElementById('themeToggle');
  const wrapper = document.getElementById('masterWrapper');
  themeBtn.addEventListener('click', () => { wrapper.classList.toggle('light-theme'); });

  /* --- Popup Logic --- */
  function toggleInfoPopup(id) {
      const popup = document.getElementById(id);
      const overlay = document.getElementById('popupOverlay');
      if(popup && overlay) {
          popup.classList.add('active');
          overlay.classList.add('active');
      }
  }
  function closeAllPopups() {
      document.querySelectorAll('.info-popup').forEach(p => p.classList.remove('active'));
      const overlay = document.getElementById('popupOverlay');
      if(overlay) overlay.classList.remove('active');
  }

  /* --- Welcome Modal Logic --- */
  function showWelcomeModal() {
      const modal = document.getElementById('welcomeModal');
      if(modal) {
          modal.style.display = 'flex';
      }
  }
  
  function closeWelcomeModal() {
      const modal = document.getElementById('welcomeModal');
      if(modal) {
          modal.style.display = 'none';
          // Start 15 Second Timer for Support Widget after closing welcome modal
          setTimeout(activateSupportWidget, 15000); 
      }
  }

  // Show Welcome Modal on DOMContentLoaded (Faster than Load)
  document.addEventListener('DOMContentLoaded', () => {
      setTimeout(showWelcomeModal, 100);
  });

  /* --- Live Support Logic --- */
  function activateSupportWidget() {
      const widget = document.getElementById('liveSupportWidget');
      if(widget) {
          widget.style.display = 'flex';
          setTimeout(() => {
              widget.classList.add('active');
          }, 50);
      }
  }

  // Close Support Widget
  document.getElementById('closeLiveSupport').addEventListener('click', (e) => {
      e.stopPropagation();
      const widget = document.getElementById('liveSupportWidget');
      if(widget) {
          widget.classList.remove('active');
          setTimeout(() => {
              widget.style.display = 'none';
              // Re-appear after 15 seconds loop
              setTimeout(activateSupportWidget, 15000);
          }, 500);
      }
  });

  /* --- Draggable Floating Widget Logic --- */
  (function() {
      const dragItem = document.getElementById('draggableTw');
      let active = false;
      let currentX;
      let currentY;
      let initialX;
      let initialY;
      let xOffset = 0;
      let yOffset = 0;

      if(dragItem) {
          // Initialize offsets to 0 so CSS positioning (middle right) works initially
          xOffset = 0;
          yOffset = 0;

          dragItem.addEventListener("touchstart", dragStart, false);
          dragItem.addEventListener("touchend", dragEnd, false);
          dragItem.addEventListener("touchmove", drag, false);

          dragItem.addEventListener("mousedown", dragStart, false);
          dragItem.addEventListener("mouseup", dragEnd, false);
          dragItem.addEventListener("mousemove", drag, false);
      }

      function dragStart(e) {
          if (e.type === "touchstart") {
              initialX = e.touches[0].clientX - xOffset;
              initialY = e.touches[0].clientY - yOffset;
          } else {
              initialX = e.clientX - xOffset;
              initialY = e.clientY - yOffset;
          }

          if (e.target === dragItem || dragItem.contains(e.target)) {
              active = true;
          }
      }

      function dragEnd(e) {
          initialX = currentX;
          initialY = currentY;
          active = false;
      }

      function drag(e) {
          if (active) {
              e.preventDefault();
          
              if (e.type === "touchmove") {
                  currentX = e.touches[0].clientX - initialX;
                  currentY = e.touches[0].clientY - initialY;
              } else {
                  currentX = e.clientX - initialX;
                  currentY = e.clientY - initialY;
              }

              xOffset = currentX;
              yOffset = currentY;

              setTranslate(currentX, currentY, dragItem);
          }
      }

      function setTranslate(xPos, yPos, el) {
          el.style.transform = "translate3d(" + xPos + "px, " + yPos + "px, 0)";
      }
  })();

  /* --- Cube Logic --- */
  (function() {
      const cubeSliderImages = [
          '/wp-content/uploads/2025/09/8.png', '/wp-content/uploads/2025/09/9.png',
          '/wp-content/uploads/2025/09/10.png', '/wp-content/uploads/2025/09/11.png',
          '/wp-content/uploads/2025/09/13.png', '/wp-content/uploads/2025/09/17.png',
          '/wp-content/uploads/2025/09/18.png'
      ];
      let cubeCurrentImageIndex = 0;
      const cubeFaceImages = document.querySelectorAll('.cube-slider-container .cube-face-image');
      if(cubeFaceImages.length > 0) {
        function cycleCubeImages() {
              cubeFaceImages.forEach((img, index) => {
                  const imageIndex = (cubeCurrentImageIndex + index) % cubeSliderImages.length;
                  if (imageIndex < cubeSliderImages.length) {
                      setTimeout(() => {
                        img.style.opacity = '0';
                        setTimeout(() => { img.src = cubeSliderImages[imageIndex]; img.style.opacity = '1'; }, 300);
                      }, index * 200);
                  }
              });
              cubeCurrentImageIndex = (cubeCurrentImageIndex + 1) % cubeSliderImages.length;
          }
          setInterval(cycleCubeImages, 4000);
      }
  })();

  /* --- BNB WIDGET LOGIC --- */
  (function(){
      const API_KEY = 'CG-dZBRsUGAYHBgY64FmvrQ3WxJ'; 
      const API_URL = 'https://api.coingecko.com/api/v3/coins/binancecoin';

      function formatNumber(num) {
        if (!num) return 'N/A';
        if (num >= 1e9) return '$' + (num / 1e9).toFixed(2) + 'B';
        if (num >= 1e6) return '$' + (num / 1e6).toFixed(2) + 'M';
        if (num >= 1e3) return '$' + (num / 1e3).toFixed(2) + 'K';
        return '$' + num.toFixed(2);
      }

      function formatSupply(num) {
        if (!num) return 'N/A';
        if (num >= 1e9) return (num / 1e9).toFixed(2) + 'B';
        if (num >= 1e6) return (num / 1e6).toFixed(2) + 'M';
        return num.toLocaleString();
      }

      function formatPercentage(value) {
        if (value === null || value === undefined) return 'N/A';
        const color = value >= 0 ? '#10b981' : '#ef4444'; 
        const sign = value >= 0 ? '+' : '';
        return `<span style="color: ${color};">${sign}${value.toFixed(2)}%</span>`;
      }

      async function fetchBNBData() {
        try {
          const response = await fetch(`${API_URL}?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false&sparkline=false&x_cg_demo_api_key=${API_KEY}`);
          if (!response.ok) { throw new Error('Failed to fetch data'); }
          
          const data = await response.json();
          const mData = data.market_data; 

          const el = (id) => document.getElementById(id);
          if(!el('current-price')) return;

          el('current-price').textContent = formatNumber(mData.current_price.usd);
          el('market-rank').textContent = '#' + data.market_cap_rank;
          el('market-cap').textContent = formatNumber(mData.market_cap.usd);
          el('volume-24h').textContent = formatNumber(mData.total_volume.usd);
          el('circulating-supply').textContent = formatSupply(mData.circulating_supply);
          el('total-supply').textContent = formatSupply(mData.total_supply);
          el('high-low-24h').textContent = `${formatNumber(mData.high_24h.usd)} / ${formatNumber(mData.low_24h.usd)}`;
          el('ath').textContent = formatNumber(mData.ath.usd);
          el('atl').textContent = formatNumber(mData.atl.usd);
          
          el('change-24h').innerHTML = formatPercentage(mData.price_change_percentage_24h);
          el('change-7d').innerHTML = formatPercentage(mData.price_change_percentage_7d);
          el('change-30d').innerHTML = formatPercentage(mData.price_change_percentage_30d);
          
          el('last-updated').textContent = new Date().toLocaleTimeString();
          
          el('loading').style.display = 'none';
          el('bnb-data').style.display = 'grid'; 
          el('error-message').style.display = 'none';

        } catch (error) {
          const loadEl = document.getElementById('loading');
          if(loadEl) loadEl.style.display = 'none';
          const errEl = document.getElementById('error-message');
          if(errEl) {
              errEl.textContent = 'Error loading data. Retrying...';
              errEl.style.display = 'block';
          }
          console.error('BNB Widget Error:', error);
        }
      }

      fetchBNBData();
      setInterval(fetchBNBData, 60000);
  })();

  /* --- INVESTMENT CALCULATOR LOGIC --- */
  (function(){
      const amountInput = document.getElementById('calc-amount');
      const rateDisplay = document.getElementById('calc-rate-display');
      const dailyProfitDisplay = document.getElementById('calc-daily-profit');
      const monthlyProfitDisplay = document.getElementById('calc-monthly-profit');

      // Plan Configuration
      const plans = [
        { min: 7000, rate: 10 },
        { min: 6000, rate: 8 },
        { min: 5000, rate: 7 },
        { min: 4000, rate: 6 },
        { min: 3000, rate: 5 },
        { min: 2000, rate: 3 },
        { min: 1500, rate: 2.5 },
        { min: 800, rate: 2 },
        { min: 700, rate: 1.5 },
        { min: 600, rate: 1.4 },
        { min: 500, rate: 1.3 },
        { min: 300, rate: 1.2 },
        { min: 150, rate: 1.1 },
        { min: 10, rate: 1 }
      ];

      function getRate(amount) {
          if (amount < 10) return 0;
          for (let plan of plans) {
             if (amount >= plan.min) return plan.rate;
          }
          return 0;
      }

      function calculate() {
          const amount = parseFloat(amountInput.value) || 0;
          const rate = getRate(amount);
          const dailyProfit = (amount * rate) / 100;
          const monthlyProfit = dailyProfit * 30;
          rateDisplay.textContent = rate + '%';
          dailyProfitDisplay.textContent = '$' + dailyProfit.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
          monthlyProfitDisplay.textContent = '$' + monthlyProfit.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
      }

      amountInput.addEventListener('input', calculate);
  })();

  /* --- GLOBE LOGIC --- */
  (function() {
    const nodeData = [
        { lat: 40.7128, lng: -74.0060, name: "New York", color: "#F3BA2F" },
        { lat: 51.5074, lng: -0.1278, name: "London", color: "#F3BA2F" },
        { lat: 50.1109, lng: 8.6821, name: "Frankfurt", color: "#F3BA2F" },
        { lat: 1.3521, lng: 103.8198, name: "Singapore", color: "#F3BA2F" },
        { lat: 35.6762, lng: 139.6503, name: "Tokyo", color: "#F3BA2F" },
        { lat: -33.8688, lng: 151.2093, name: "Sydney", color: "#F3BA2F" },
        { lat: -23.5505, lng: -46.6333, name: "Sao Paulo", color: "#F3BA2F" },
        { lat: 19.0760, lng: 72.8777, name: "Mumbai", color: "#F3BA2F" }
    ];

    const elem = document.getElementById('globe-viz');
    if(elem) {
        const globe = Globe()
          (elem)
          .globeImageUrl('https://unpkg.com/three-globe/example/img/earth-night.jpg')
          .backgroundColor('rgba(0,0,0,0)')
          .width(elem.clientWidth)
          .height(elem.clientHeight)
          .pointsData(nodeData)
          .pointLat('lat')
          .pointLng('lng')
          .pointColor('color')
          .pointAltitude(0.1) 
          .pointRadius(0.6)   
          .ringsData(nodeData)
          .ringColor(d => t => `rgba(243, 186, 47, ${1-t})`)
          .ringMaxRadius(5)
          .ringPropagationSpeed(3)
          .ringRepeatPeriod(800)
          .labelsData(nodeData)
          .labelLat('lat')
          .labelLng('lng')
          .labelText('name')
          .labelSize(1.5)
          .labelDotRadius(0.5)
          .labelColor(() => 'rgba(255, 255, 255, 0.9)')
          .labelResolution(2);
        globe.controls().autoRotate = true;
        globe.controls().autoRotateSpeed = 0.8; 
        globe.controls().enableZoom = false;

        window.addEventListener('resize', () => {
            if(elem) {
                globe.width(elem.clientWidth);
                globe.height(elem.clientHeight);
            }
        });
        setTimeout(() => {
            if(elem) {
                globe.width(elem.clientWidth);
                globe.height(elem.clientHeight);
            }
        }, 100);
    }
  })();
  
  /* --- TIMELINE LOGIC (UPDATED WITH MULTI-LINK SUPPORT) --- */
  (function(){
    const timelineData = [
        { 
            year: 2013, 
            title: "The Beginning of Excellence", 
            subtitle: "2013 - 15% Growth | 150 Customers", 
            growth: "15%", 
            customers: "150",
            links: [
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzA3MjkwMDIzNGFkaXF6a2N4/document?format=pdf&download=0"
            ],
            details: `<p>2013 marked the inception of our professional trading services. With a vision to democratize access to sophisticated investment strategies, we launched our platform with a modest but dedicated team.</p><h4>Key Achievements:</h4><ul><li>Successfully onboarded our first 150 clients within 8 months</li><li>Achieved a remarkable 15% annual return despite market volatility</li><li>Established our core trading algorithms</li></ul>`
        },
        { 
            year: 2014, 
            title: "Scaling Operations", 
            subtitle: "2014 - 22% Growth | 1,280 Customers", 
            growth: "22%", 
            customers: "1,280",
            links: [
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzA5NDY5NzI2OGFkaXF6a2N4/document?format=pdf&download=0",
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzEwMzM5MDE0MGFkaXF6a2N4/document?format=pdf&download=0",
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzEwMzM4ODk5NGFkaXF6a2N4/document?format=pdf&download=0"
            ],
            details: `<p>Building on our solid foundation, 2014 was the year of strategic expansion. We enhanced our technology infrastructure.</p><h4>Key Achievements:</h4><ul><li>Expanded client base by 753% to reach 1,280 active traders</li><li>Delivered 22% annual returns through diversified strategies</li><li>Launched our proprietary trading platform</li></ul>`
        },
        { 
            year: 2015, 
            title: "Market Leadership", 
            subtitle: "2015 - 35% Growth | 3,450 Customers", 
            growth: "35%", 
            customers: "3,450",
            links: [
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzExNzM0NTUzNWFkaXF6a2N4/document?format=pdf&download=0",
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzEzMzgwNDc3MmFkaXF6a2N4/document?format=pdf&download=0"
            ],
            details: `<p>2015 marked our emergence as a market leader. With exceptional 35% returns and rapid client growth.</p><h4>Key Achievements:</h4><ul><li>Achieved outstanding 35% returns across all portfolios</li><li>Grew client base to 3,450 active investors</li><li>Introduced AI‐powered market analysis tools</li></ul>`
        },
        { 
            year: 2016, 
            title: "Innovation Breakthrough", 
            subtitle: "2016 - 45% Growth | 8,720 Customers", 
            growth: "45%", 
            customers: "8,720",
            links: [
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzE0Mzg2MjM5MmFkaXF6a2N4/document?format=pdf&download=0",
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzE1OTUxODUyMmFkaXF6a2N4/document?format=pdf&download=0"
            ],
            details: `<p>Revolutionary technological breakthroughs led to record‐breaking performance.</p><h4>Key Achievements:</h4><ul><li>45% annual returns via advanced algorithms</li><li>Expanded to 8,720 investors worldwide</li><li>Launched a mobile trading platform</li></ul>`
        },
        { 
            year: 2017, 
            title: "Global Expansion", 
            subtitle: "2017 - 52% Growth | 21,100 Customers", 
            growth: "52%", 
            customers: "21,100",
            links: [
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzE2ODk1OTk5MmFkaXF6a2N4/document?format=pdf&download=0",
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzE3MzY2OTAwNmFkaXF6a2N4/document?format=pdf&download=0"
            ],
            details: `<p>Global presence established across major markets.</p><h4>Key Achievements:</h4><ul><li>52% annual returns</li><li>21,100 clients in 25 countries</li><li>Offices in London, Singapore, New York</li></ul>`
        },
        { 
            year: 2018, 
            title: "Technology Revolution", 
            subtitle: "2018 - 58% Growth | 45,650 Customers", 
            growth: "58%", 
            customers: "45,650",
            links: [
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzE5ODI4NzkxMmFkaXF6a2N4/document?format=pdf&download=0",
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzIxNjQ2OTc1MWFkaXF6a2N4/document?format=pdf&download=0"
            ],
            details: `<p>AI + Quantum integration across strategies.</p><h4>Key Achievements:</h4><ul><li>58% returns via AI optimization</li><li>45,650 clients</li><li>Quantum computing adoption</li></ul>`
        },
        { 
            year: 2019, 
            title: "Peak Performance", 
            subtitle: "2019 - 61% Growth | 123,300 Customers", 
            growth: "61%", 
            customers: "123,300",
            links: [
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzIyODg3MDc2OGFkaXF6a2N4/document?format=pdf&download=0",
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzI0MDY1MDQ5OWFkaXF6a2N4/document?format=pdf&download=0"
            ],
            details: `<p>Record results & major awards.</p><h4>Key Achievements:</h4><ul><li>61% returns</li><li>123,300 clients</li><li>ESG strategies launched</li></ul>`
        },
        { 
            year: 2020, 
            title: "Resilience Through Crisis", 
            subtitle: "2020 - 55% Growth | 278,800 Customers", 
            growth: "55%", 
            customers: "278,800",
            links: [
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzI1NzM1Mjc0M2FkaXF6a2N4/document?format=pdf&download=0",
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzI4NjAzODMyOWFkaXF6a2N4/document?format=pdf&download=0"
            ],
            details: `<p>Strong performance during market turbulence.</p><h4>Key Achievements:</h4><ul><li>55% returns during crisis</li><li>278,800 investors</li><li>Advanced risk systems</li></ul>`
        },
        { 
            year: 2021, 
            title: "Recovery & Growth", 
            subtitle: "2021 - 48% Growth | 432,200 Customers", 
            growth: "48%", 
            customers: "432,200",
            links: [
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzI5MTQ0MzI3MmFkaXF6a2N4/document?format=pdf&download=0",
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzMwMDc5NTI0NGFkaXF6a2N4/document?format=pdf&download=0"
            ],
            details: `<p>Strategic growth after pandemic.</p><h4>Key Achievements:</h4><ul><li>48% annual returns</li><li>432,200 clients</li><li>Expanded trading infrastructure</li></ul>`
        },
        { 
            year: 2022, 
            title: "Strategic Advancement", 
            subtitle: "2022 - 52% Growth | 585,500 Customers", 
            growth: "52%", 
            customers: "585,500",
            links: [
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzMyOTg5ODAwOWFkaXF6a2N4/document?format=pdf&download=0",
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzM1MTcyODUzMWFkaXF6a2N4/document?format=pdf&download=0"
            ],
            details: `<p>Continued strategic advancement of core technologies and client offerings.</p><h4>Key Achievements:</h4><ul><li>52% annual returns</li><li>585,500 clients</li><li>Focus on automated compliance</li></ul>`
        },
        { 
            year: 2023, 
            title: "Excellence Refined", 
            subtitle: "2023 - 58% Growth | 687,750 Customers", 
            growth: "58%", 
            customers: "687,750",
            links: [
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzM2OTQzMjAxMWFkaXF6a2N4/document?format=pdf&download=0",
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzM4MDQ4OTA1MGFkaXF6a2N4/document?format=pdf&download=0"
            ],
            details: `<p>Refining excellence across all operational metrics, achieving superior client satisfaction and returns.</p><h4>Key Achievements:</h4><ul><li>58% annual returns</li><li>687,750 clients</li><li>Launched new high-yield products</li></ul>`
        },
        { 
            year: 2024, 
            title: "Future Leadership", 
            subtitle: "2024 - 62% Growth | 800,000 Customers", 
            growth: "62%", 
            customers: "800,000",
            links: [
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzQxMTYxMDU1OWFkaXF6a2N4/document?format=pdf&download=0",
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzQyMjA1NDg3N2FkaXF6a2N4/document?format=pdf&download=0"
            ],
            details: `<p>Poised for future market leadership with an expanding client base and record-breaking projected returns.</p><h4>Key Achievements:</h4><ul><li>62% projected annual returns</li><li>Targeting 800,000 clients</li><li>Next-generation platform overhaul</li></ul>`
        },
        { 
            year: 2025, 
            title: "Global Dominance", 
            subtitle: "2025 - Projected Growth | 900,000 Customers", 
            growth: "65%", 
            customers: "900,000",
            links: [
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzQ1NTE3NTUxMmFkaXF6a2N4/document?format=pdf&download=0",
                "https://find-and-update.company-information.service.gov.uk/company/08405465/filing-history/MzQ3ODM5NjM3OGFkaXF6a2N4/document?format=pdf&download=0"
            ],
            details: `<p>Continuing our legacy of excellence into 2025 with expanded market reach and innovative financial solutions.</p><h4>Projected Milestones:</h4><ul><li>Targeting 65% annual growth</li><li>Expanding to 900,000+ satisfied clients</li><li>Introducing next-gen blockchain integration</li></ul>`
        }
    ];

    window.openTimelineModal = function(index) {
        const data = timelineData[index];
        const modalOverlay = document.getElementById('timelineModalOverlay');
        document.getElementById('modalTitle').textContent = data.title;
        document.getElementById('modalSubtitle').textContent = data.subtitle;
        document.getElementById('modalBody').innerHTML = data.details;
        
        // Dynamic Link Generation
        const linkBox = document.getElementById('modalLinkBox');
        linkBox.innerHTML = ''; // Clear previous
        
        // Add Label
        const label = document.createElement('span');
        label.className = 'modal-link-label';
        label.textContent = 'Download Reports:';
        linkBox.appendChild(label);

        // Create Container for links
        const linksWrapper = document.createElement('div');
        linksWrapper.className = 'modal-links-wrapper';
        
        // Generate Buttons
        if (data.links && data.links.length > 0) {
            data.links.forEach((url, i) => {
                const a = document.createElement('a');
                a.href = url;
                a.target = '_blank';
                a.className = 'modal-doc-link';
                a.textContent = `Document ${i + 1} (PDF)`;
                linksWrapper.appendChild(a);
            });
        } else {
             const span = document.createElement('span');
             span.style.color = 'var(--text-secondary)';
             span.style.fontSize = '13px';
             span.textContent = 'No documents available for this year.';
             linksWrapper.appendChild(span);
        }
        
        linkBox.appendChild(linksWrapper);

        modalOverlay.classList.add('active');
        document.body.style.overflow = 'hidden'; 
    }

    window.closeTimelineModal = function(event) {
        if (event.target.id === 'timelineModalOverlay' || event.target.className === 'modal-close') {
            const modalOverlay = document.getElementById('timelineModalOverlay');
            modalOverlay.classList.remove('active');
            document.body.style.overflow = ''; 
        }
    }

    const grid = document.getElementById('timelineGrid');
    if (grid) {
        timelineData.forEach((data, index) => {
            const box = document.createElement('div');
            box.className = 'timeline-box';
            const formattedCustomers = data.customers.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            box.innerHTML = `
                <div class="box-year">${data.year}</div>
                <div class="box-data"><strong>${data.growth}</strong> growth</div>
                <div class="box-data">${formattedCustomers} customers</div>
            `;
            box.onclick = () => window.openTimelineModal(index);
            grid.appendChild(box);
        });
    }
  })();

  /* --- PRC CREDENTIALS LOGIC --- */
  (function() {
    const prcCredentialsData = [
        { 
            title: "FCA Register", 
            badge: "REGULATED UK",
            link: "https://register.fca.org.uk/s/firm?id=001b000000NMfpRAAT",
            details: `
                <p>Paul Rice Investment Planning Limited (Company Number: 08405465) is proudly and officially registered with the Financial Conduct Authority (FCA) in the United Kingdom. This registration serves as a testament to our commitment to meeting the highest regulatory standards and ensuring the safety and trust of our clients.</p>
                <p>As a regulated financial services provider, we adhere to strict compliance requirements, ethical conduct guidelines, and industry best practices. Clients can engage with confidence, knowing their investments and financial strategies are overseen by a licensed, transparent, and trustworthy institution.</p>
                <p>Our FCA recognition reflects our dedication to client protection, regulatory compliance, and professional excellence within the financial industry.</p>`
        },
        { 
            title: "Companies House (UK)", 
            badge: "LEGAL VERIFIED",
            link: "https://find-and-update.company-information.service.gov.uk/company/08405465",
            details: `
                <p>Paul Rice Investment Planning Limited (Company Number: 08405465) is officially registered with Companies House in the United Kingdom. This formal registration confirms our legal and operational credibility, highlighting our commitment to professional governance, compliance, and full transparency in all our business operations.</p>
                <p>Our team provides bespoke financial advice, investment planning, and wealth management services tailored to individual and corporate client needs. The recognition by Companies House underscores our dedication to excellence, ethical business practices, and the highest level of accountability.</p>
                <p>Being listed and verified on Companies House ensures that all stakeholders, clients, and partners can trust our operations and verify our credentials independently.</p>`
        },
        { 
            title: "Unbiased.co.uk", 
            badge: "ADVISORY LISTING",
            link: "https://www.unbiased.co.uk/profile/financial-adviser/paul-rice-investment-planning-limited-519092",
            details: `
                <p>Paul Rice Investment Planning Limited is officially listed on Unbiased.co.uk, one of the UK's most respected platforms for connecting clients with qualified financial advisers. This recognition emphasizes our professional standing and reliability in providing independent financial advice.</p>
                <p>We deliver a wide range of advisory services, including investment planning, wealth management, and corporate and personal financial consulting. Our presence on Unbiased.co.uk ensures clients can verify our qualifications and trust our expertise.</p>
                <p>Being featured on a leading independent platform reinforces our credibility and provides clients with transparent access to our professional profile.</p>`
        },
        { 
            title: "LeasingLife", 
            badge: "INDUSTRY RECOGNITION",
            link: "https://www.leasinglife.com/news/time-finance-expands-invoice-finance-team-with-key-appointment/",
            details: `
                <p>Paul Rice Investment Planning Limited is recognized on LeasingLife, highlighting our expertise in financial planning and advisory within the UK financial sector. This feature demonstrates our commitment to professional excellence and industry credibility.</p>
                <p>Our team provides tailored investment strategies, wealth management, and corporate advisory services, ensuring that every client receives guidance aligned with their financial goals.</p>
                <p>Being highlighted on LeasingLife reinforces our professional reputation and credibility within the financial industry.</p>`
        },
        { 
            title: "FinancialAdvisorUK", 
            badge: "ADVISORY LISTING",
            link: "https://financialadvisoruk.com/advisor/united-kingdom/birmingham-1/investment-cat/paul-rice-investment-planning-limited/",
            details: `
                <p>Paul Rice Investment Planning Limited is listed on FinancialAdvisorUK, highlighting our reputation as a credible and professional financial advisory firm in Birmingham and across the UK. This listing demonstrates our commitment to providing expert guidance and trustworthy investment services.</p>
                <p>Our experienced team delivers tailored solutions in investment planning, wealth management, and corporate financial consulting. The recognition ensures that clients can confidently engage with our advisory services, knowing they meet high professional standards.</p>
                <p>Being featured on FinancialAdvisorUK reinforces our credibility and provides clients with direct access to our verified professional profile.</p>`
        },
        { 
            title: "CEGINFORMACIO", 
            badge: "INTERNATIONAL LISTING",
            link: "https://www.ceginformacio.hu/cr10003336296",
            details: `<p>Paul Rice Investment Planning Limited is officially listed on CEGINFORMACIO, demonstrating our recognition as a credible and professional entity in international business directories.</p>`
        },
        { 
            title: "DNB Business Directory", 
            badge: "INTERNATIONAL LISTING",
            link: "https://www.dnb.com/business-directory/company-profiles.paul_rice_investment_planning_limited.3f97a301974ec2cdc091c15de604c7e8.html",
            details: `
                <p>Paul Rice Investment Planning Limited is recognized in the DNB business directory, emphasizing our operational credibility and commitment to high-quality financial services.</p>
                <p>Our services include investment planning, wealth management, and advisory solutions, customized to client-specific needs and objectives.</p>`
        },
        { 
            title: "Endole", 
            badge: "UK BUSINESS INSIGHT",
            link: "https://open.endole.co.uk/insight/company/08405465-paul-rice-investment-planning-limited",
            details: `
                <p>Paul Rice Investment Planning Limited is officially listed on Endole, a trusted UK business insights platform. This listing confirms our operational credibility and commitment to transparency.</p>
                <p>Our advisory team offers tailored solutions in financial planning, investment management, and corporate advisory, ensuring high-quality, client-focused outcomes.</p>
                <p>Being featured on Endole reinforces our professional standing and transparency.</p>`
        },
        { 
            title: "Pomanda", 
            badge: "UK BUSINESS INSIGHT",
            link: "https://pomanda.com/company/08405465/paul-rice-investment-planning-limited",
            details: `
                <p>Paul Rice Investment Planning Limited is listed on Pomanda, highlighting our operational transparency and professional credibility within the UK business landscape.</p>
                <p>Our team provides expert financial planning, investment management, and corporate consulting, designed to meet the unique needs of each client.</p>
                <p>Being featured on Pomanda reinforces our reliability and professional reputation.</p>`
        },
        { 
            title: "Tracxn", 
            badge: "GLOBAL PLATFORM",
            link: "https://tracxn.com/d/legal-entities/united-kingdom/paul-rice-investment-planning-limited",
            details: `
                <p>Paul Rice Investment Planning Limited is officially listed on Tracxn, a global platform that tracks innovative companies and fast-growing businesses. This listing highlights our presence and credibility within the financial advisory industry.</p>
                <p>Our team of professionals provides tailored financial solutions, including wealth management, investment planning, and strategic guidance for individuals and corporate clients.</p>
                <p>Being featured on Tracxn reinforces our dedication to quality service, transparency, and industry recognition.</p>`
        },
        { 
            title: "YouControl", 
            badge: "INTERNATIONAL LISTING",
            link: "https://youcontrol.com.ua/en/catalog/gb-card/08405465/",
            details: `<p>Paul Rice Investment Planning Limited is recognized on YouControl, an international business information platform. This listing underscores our operational credibility and professional standing.</p>`
        },
        { 
            title: "Identeco", 
            badge: "UK BUSINESS INSIGHT",
            link: "https://www.identeco.co.uk/search/company/08405465",
            details: `
                <p>Paul Rice Investment Planning Limited is listed on Identeco, highlighting our professional credibility and operational transparency.</p>
                <p>We provide bespoke financial planning and investment services tailored to individual and corporate client needs.</p>`
        }
    ];
    window.prcOpenModal = function(data) {
        const modalOverlay = document.getElementById('prcModalOverlay');
        document.getElementById('prcModalTitle').textContent = data.title;
        document.getElementById('prcModalBody').innerHTML = data.details;
        document.getElementById('prcModalLink').href = data.link;

        modalOverlay.classList.add('prc-active');
        document.body.style.overflow = 'hidden'; 
    };
    window.prcCloseModal = function(event) {
        if (event.target.id === 'prcModalOverlay' || event.target.className === 'prc-modal-close') {
            const modalOverlay = document.getElementById('prcModalOverlay');
            modalOverlay.classList.remove('prc-active');
            document.body.style.overflow = '';
        }
    };

    const grid = document.getElementById('prcGrid');
    if (grid) {
        prcCredentialsData.forEach((data, index) => {
            const box = document.createElement('div');
            box.className = 'prc-card';
            box.onclick = function() {
                window.prcOpenModal(data);
            };
            box.innerHTML = `
                <svg class="prc-card-icon-svg" viewBox="0 0 24 24">
                  <circle cx="12" cy="12" r="10"></circle>
                  <line x1="2" y1="12" x2="22" y2="12"></line>
                  <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                </svg>
                <div class="prc-card-title">${data.title}</div>
                <div class="prc-card-badge">${data.badge}</div>
            `;
            grid.appendChild(box);
        });
    }
  })();

  /* --- SCROLL ANIMATION LOGIC --- */
  (function() {
      const observerOptions = {
          threshold: 0.2
      };
      const observer = new IntersectionObserver((entries) => {
          entries.forEach(entry => {
              if (entry.isIntersecting) {
                  entry.target.classList.add('cta-animate-active');
                  observer.unobserve(entry.target);
              }
          });
      }, observerOptions);
      
      const ctaSection = document.getElementById('ctaSection');
      if (ctaSection) observer.observe(ctaSection);
  })();

  /* --- PARTICLE BACKGROUND LOGIC --- */
  (function() {
      const canvas = document.getElementById('particle-canvas');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      let width, height;
      let particles = [];

      function resize() {
          width = canvas.width = window.innerWidth;
          height = canvas.height = window.innerHeight;
      }

      class Particle {
          constructor() {
              this.reset();
              // Scatter initial positions randomly
              this.x = Math.random() * width;
              this.y = Math.random() * height;
          }

          reset() {
              this.x = Math.random() * width;
              this.y = Math.random() * height;
              // Random velocity vector
              this.vx = (Math.random() - 0.5) * 0.4; // Slow
              this.vy = (Math.random() - 0.5) * 0.4;
              this.size = Math.random() * 1.2 + 0.2; // Range: 0.2px to 1.4px
              this.alpha = Math.random() * 0.5 + 0.3; // Slightly more opaque
              this.life = Math.random() * 100;
          }

          update() {
              this.x += this.vx;
              this.y += this.vy;
              this.life++;

              // Slight wobble
              this.x += Math.sin(this.life * 0.01) * 0.1;

              // Wrap around screen
              if (this.x < 0) this.x = width;
              if (this.x > width) this.x = 0;
              if (this.y < 0) this.y = height;
              if (this.y > height) this.y = 0;
          }

          draw() {
              ctx.fillStyle = `rgba(255, 255, 255, ${this.alpha})`;
              ctx.beginPath();
              ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
              ctx.fill();
          }
      }

      function init() {
          resize();
          
          // --- MOBILE PERFORMANCE OPTIMIZATION ---
          // Increase divisor on mobile to drastically reduce particle count.
          // Mobile (less than 768px): Divisor 25000 (very few particles)
          // Desktop: Divisor 6000 (normal density)
          const isMobile = window.innerWidth < 768;
          const densityDivisor = isMobile ? 25000 : 6000;
          
          const particleCount = Math.floor((width * height) / densityDivisor); 
          particles = [];
          for (let i = 0; i < particleCount; i++) {
              particles.push(new Particle());
          }
          animate();
      }

      function animate() {
          ctx.clearRect(0, 0, width, height);
          particles.forEach(p => {
              p.update();
              p.draw();
          });
          requestAnimationFrame(animate);
      }

      let resizeTimeout;
      window.addEventListener('resize', () => {
          // Debounce resize to prevent mobile browser address bar flicker resets
          clearTimeout(resizeTimeout);
          resizeTimeout = setTimeout(() => {
              // Only re-init if width changes significantly (orientation change)
              if (Math.abs(canvas.width - window.innerWidth) > 50) {
                  init();
              } else {
                  resize(); // Just update canvas dim
              }
          }, 200);
      });

      init();
  })();
</script>				</div>
				</div>
					</div>
				</div>
				</div>
		<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/hello-elementor/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<script src="/wp-content/themes/hello-elementor/assets/js/hello-frontend.js?ver=3.4.5" id="hello-theme-frontend-js"></script>
<script src="/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.33.3" id="elementor-webpack-runtime-js"></script>
<script src="/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.33.3" id="elementor-frontend-modules-js"></script>
<script src="/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script id="elementor-frontend-js-before">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}},"hasCustomBreakpoints":false},"version":"3.33.3","is_static":false,"experimentalFeatures":{"e_font_icon_svg":true,"additional_custom_breakpoints":true,"container":true,"theme_builder_v2":true,"hello-theme-header-footer":true,"nested-elements":true,"home_screen":true,"global_classes_should_enforce_capabilities":true,"e_variables":true,"cloud-library":true,"e_opt_in_v4_page":true,"import-export-customization":true,"mega-menu":true,"e_pro_variables":true},"urls":{"assets":"\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"\/wp-admin\/admin-ajax.php","uploadUrl":"\/wp-content\/uploads"},"nonces":{"floatingButtonsClickTracking":"06eed99474"},"swiperClass":"swiper","settings":{"page":[],"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description","hello_header_logo_type":"logo","hello_header_menu_layout":"horizontal","hello_footer_logo_type":"logo"},"post":{"id":4640,"title":"prinvesment.com%20%E2%80%93%20Secure%20transactions","excerpt":"","featuredImage":false}};
//# sourceURL=elementor-frontend-js-before
</script>
<script src="/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.33.3" id="elementor-frontend-js"></script>
<script src="/wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.min.js?ver=3.33.2" id="elementor-pro-webpack-runtime-js"></script>
<script src="/wp-includes/js/dist/hooks.min.js?ver=dd5603f07f9220ed27f1" id="wp-hooks-js"></script>
<script src="/wp-includes/js/dist/i18n.min.js?ver=c26c3dc7bed366793375" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
</script>
<script id="elementor-pro-frontend-js-before">
var ElementorProFrontendConfig = {"ajaxurl":"\/wp-admin\/admin-ajax.php","nonce":"5c751f9187","urls":{"assets":"\/wp-content\/plugins\/elementor-pro\/assets\/","rest":"\/wp-json\/"},"settings":{"lazy_load_background_images":false},"popup":{"hasPopUps":false},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"},"x-twitter":{"title":"X"},"threads":{"title":"Threads"}},"facebook_sdk":{"lang":"en_US","app_id":""},"lottie":{"defaultAnimationUrl":"\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
//# sourceURL=elementor-pro-frontend-js-before
</script>
<script src="/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.33.2" id="elementor-pro-frontend-js"></script>
<script src="/wp-content/plugins/elementor-pro/assets/js/elements-handlers.min.js?ver=3.33.2" id="pro-elements-handlers-js"></script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"/wp-includes/js/wp-emoji-release.min.js?ver=6.9"}}
</script>
<script type="module">
/*! This file is auto-generated */
const a=JSON.parse(document.getElementById("wp-emoji-settings").textContent),o=(window._wpemojiSettings=a,"wpEmojiSettingsSupports"),s=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const a=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===a[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,a){let r;const o=(r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),s=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(e=>{s[e]=t(o,e,n,a)}),s}function r(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}a.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),c.toString(),p.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"});const r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=e=>{i(n=e.data),r.terminate(),t(n)})}catch(e){}i(n=f(s,u,c,p))}t(n)}).then(e=>{for(const n in e)a.supports[n]=e[n],a.supports.everything=a.supports.everything&&a.supports[n],"flag"!==n&&(a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&a.supports[n]);var t;a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&!a.supports.flag,a.supports.everything||((t=a.source||{}).concatemoji?r(t.concatemoji):t.wpemoji&&t.twemoji&&(r(t.twemoji),r(t.wpemoji)))});
//# sourceURL=/wp-includes/js/wp-emoji-loader.min.js
</script>
	<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v833ccba57c9e4d2798f2e76cebdd09a11778172276447" integrity="sha512-57MDmcccJXYtNnH+ZiBwzC4jb2rvgVCEokYN+L/nLlmO8rfYT/gIpW2A569iJ/3b+0UEasghjuZH/ma3wIs/EQ==" data-cf-beacon='{"version":"2024.11.0","token":"8c3f7f99f8c14a8dbb1b026ea3e9e1a3","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>
